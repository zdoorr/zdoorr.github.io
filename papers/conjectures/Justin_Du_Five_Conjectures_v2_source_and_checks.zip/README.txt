Five proposed conjectures and research problems, version 2
Justin Du | 14 November 2026 | fbphdu@gmail.com

This is the English source and verification supplement for the five notes.
The general assertions remain open. Item 03 is an open extremal problem;
item 04 is its separate dyadic conjecture. The papers and supporting proofs
received AI-assisted internal review and exact checks, not independent
external peer review or proof-assistant formalization.

Directory layout
  papers/*_en/: editable English main.tex and its included sections/references.
  output/pdf/: the five corresponding English PDFs.
  research/: bounded Python checks, results, small explicit witnesses.
  research/archive/: OLD catalogues, certificate source and completion logs.
  SHA256SUMS.txt: checksums of every other file in this supplement.

With Python 3.10+, run from research/ (standard library only):
  python -B verify_sieve.py
  python -B verify_square_cycles.py
  python -B verify_permutations.py
  python -B verify_parity_reductions.py
  python -B verify_trees.py
  python -B verify_extensions_v2.py
  python -B publication_proof_checks.py

All these runs are bounded small checks. They do not infer infinite results
from a cutoff. The manuscripts contain the infinite arguments. The last
script independently verifies polynomial derivative identities on their
continuous parameter boxes, cross-checks the pruning method against complete
enumeration at n=2,4,6,8, and checks the specified rotation obstruction and
rational constants. Its passing status is not independent peer review.

To build an English note, run XeLaTeX twice on its main.tex. Standard packages
needed: Latin Modern, AMS, mathtools, array/tabularx/longtable and hyperref.
No Chinese fonts, local Windows paths or package installations are needed
by the verification programs. These sources contain no local build binaries.

The square-cycle gzip is a complete set of 4,775 explicit witnesses for
71<=n<=120, including every deleted label. Its generator independently checks
each vertex set and every squared sum. gzip timestamps can change its byte
hash on regeneration without changing the mathematical witnesses.

Archived-computation boundary
The n=16 endpoint-energy theorem uses OLD exhaustive runs. Source, threshold
logs and the independent implementation are retained. The manuscript proves
the pruning bound and states the dependence. To reproduce the threshold run
with a C++17 compiler (this is larger than the Python checks):
  g++ -O3 -std=c++17 archive/restricted32/threshold.cpp -o threshold
  ./threshold 16 10591
  g++ -O3 -std=c++17 archive/restricted32/halfstart_check.cpp -o halfstart
  ./halfstart
These are research reproduction commands, not requirements for reading the
papers. They were not rerun for this release. The third paper's n=9..16
global table is an archived classification; fresh witness recounts alone do
not establish its global exhaustiveness. The tree archive retains original
summaries/audits (some in their original Chinese); the reported large tree
enumerations and separate old infinite-family arguments were not rerun or
reproved here. Large underlying tree data are not included in this supplement.

Corrections in the publication review
The global growth proof now handles remainder zero explicitly, without
invoking an undefined a_0. The dyadic abstract explicitly restricts the
47,996 bound to the one-odd-entry class, and the proof handles unrealizable
records and the forced central position of the odd entry. Both language
versions were synchronized locally; this public package contains English.

These notes do not establish absolute historical priority. Generative AI
contributed substantially to problem exploration, derivations, drafting
and verification code; each manuscript discloses the extent and limits.
