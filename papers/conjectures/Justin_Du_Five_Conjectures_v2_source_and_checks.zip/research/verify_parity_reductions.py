"""Small exact checks for the central-cut and parity-run reductions.

Standard library only. No GPU, disk cache, or n=32 enumeration.
Run with python -B src/theory_small.py.
"""
import collections
import itertools
import json
from pathlib import Path


def differences(path):
    return tuple(abs(a - b) for a, b in zip(path, path[1:]))


def check(n):
    m = n // 2
    full = collections.Counter(
        differences(p) for p in itertools.permutations(range(n))
    )
    # This construction uses only paths on m labels, rather than full paths.
    half = collections.defaultdict(lambda: collections.defaultdict(collections.Counter))
    for p in itertools.permutations(range(n), m):
        mask = sum(1 << x for x in p)
        half[mask][differences(p)][p[-1]] += 1
    central = collections.Counter()
    all_mask = (1 << n) - 1
    for mask, a_words in half.items():
        for a, a_ends in a_words.items():
            for b, b_ends in half[all_mask ^ mask].items():
                for i, count_a in a_ends.items():
                    for j, count_b in b_ends.items():
                        central[a + (abs(i - j),) + b[::-1]] += count_a * count_b
    assert central == full, "Central-cut formula disagrees with full permutations"

    # Independent two-odd-jump contraction, using paths and two-path covers on [m].
    endpoint_matrices = collections.defaultdict(collections.Counter)
    covers = collections.defaultdict(collections.Counter)
    for p in itertools.permutations(range(m)):
        endpoint_matrices[differences(p)][p[0], p[-1]] += 1
        for a_size in range(1, m):
            a, c = differences(p[:a_size]), differences(p[a_size:])
            covers[a, c][p[a_size - 1], p[a_size]] += 1
    two_odd = collections.Counter()
    for (a, c), p_entries in covers.items():
        for b, e_entries in endpoint_matrices.items():
            for (u, v), p_count in p_entries.items():
                for (x, y), e_count in e_entries.items():
                    for first_parity in (0, 1):
                        t1 = abs((2*u + first_parity) - (2*x + 1-first_parity))
                        t2 = abs((2*v + first_parity) - (2*y + 1-first_parity))
                        word = tuple(2*z for z in a) + (t1,) + tuple(2*z for z in b) + (t2,) + tuple(2*z for z in c)
                        two_odd[word] += p_count * e_count
    expected_two_odd = collections.Counter({w: c for w, c in full.items() if sum(x % 2 for x in w) == 2})
    assert two_odd == expected_two_odd, "Two-path contraction disagrees with full permutations"

    max_by_odd_count = collections.defaultdict(int)
    first_bad_cs = None
    for word, count in full.items():
        parity = 0
        visits = [1, 0]
        run_lengths = [1]
        for distance in word:
            if distance % 2:
                parity ^= 1
                run_lengths.append(1)
            else:
                run_lengths[-1] += 1
            visits[parity] += 1
        assert visits == [m, m]
        assert sum(run_lengths[::2]) == sum(run_lengths[1::2]) == m
        odd_count = len(run_lengths) - 1
        max_by_odd_count[odd_count] = max(max_by_odd_count[odd_count], count)

        a, t, b = word[:m - 1], word[m - 1], word[m:][::-1]
        same_a = full.get(a + (t,) + a[::-1], 0)
        same_b = full.get(b + (t,) + b[::-1], 0)
        if first_bad_cs is None and count * count > same_a * same_b:
            first_bad_cs = {
                "record": word, "count": count, "half_A": a, "half_B": b,
                "bridge": t, "self_A_count": same_a, "self_B_count": same_b,
            }

    return {
        "n": n,
        "permutations": sum(full.values()),
        "distinct_records": len(full),
        "central_cut_all_records_verified": True,
        "two_odd_contraction_all_records_verified": True,
        "two_odd_distinct_records": len(two_odd),
        "parity_balance_all_records_verified": True,
        "maximum_by_number_of_odd_entries": dict(sorted(max_by_odd_count.items())),
        "counterexample_to_naive_self_gluing_Cauchy_Schwarz": first_bad_cs,
    }


def main():
    results = {"scope": "Complete exact checks at n=4 and n=8 only", "checks": [check(4), check(8)]}
    path = Path(__file__).resolve().parent / "parity_reductions_verification.json"
    path.write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
