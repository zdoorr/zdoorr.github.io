"""Bounded exact checks for the cyclic-gap variance manuscript."""
from collections import Counter
from fractions import Fraction as F
from math import gcd, isqrt, prod
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def gaps(n):
    residues = [a for a in range(1, n) if gcd(a, n) == 1]
    return [b-a for a, b in zip(residues, residues[1:])] + [n+residues[0]-residues[-1]]


def stats(n):
    g = gaps(n)
    h = len(g)
    mu = F(n, h)
    return mu, F(sum(x*x for x in g), h)-mu*mu


def factors(n):
    out = []
    p = 2
    while p*p <= n:
        if n % p == 0:
            out.append(p)
            n //= p
            if n % p == 0:
                return None
        p += 1
    if n > 1:
        out.append(n)
    return out


def main():
    primes = [p for p in range(2, 114) if all(p % q for q in range(2, isqrt(p)+1))]
    bases = {k: prod(primes[:k]) for k in range(2, 6)}
    base_values = {k: stats(n)[1] for k, n in bases.items()}
    checked = Counter()
    maximizers = {}
    for n in range(2, 5001):
        fs = factors(n)
        if fs is None or len(fs) < 2:
            continue
        k = len(fs)
        v = stats(n)[1]
        assert v <= base_values[k], (n, v)
        checked[k] += 1
        if v == base_values[k]:
            maximizers.setdefault(k, []).append(n)
    odd_pair_checks = 0
    for index, p in enumerate(primes[1:12]):
        for q in primes[1:12][index+1:]:
            n = p*q
            actual = Counter(gaps(n))
            expected = Counter({1: (p-2)*(q-2), 2: p+q-5, 3: 2})
            assert actual == expected, (p, q)
            h = (p-1)*(q-1)
            assert sum(x*x*c for x, c in actual.items()) == n+2*p+2*q+2
            assert stats(n)[1] < 1
            odd_pair_checks += 1
    tail_checks = []
    for m in [3, 5, 6, 15, 21, 30, 105, 210]:
        g = gaps(m)
        mu, v = stats(m)
        correlation = F(sum(g[i-1]*g[i] for i in range(len(g))), len(g))
        choices = [p for p in primes if p > max(g) and m % p][:5]
        for p in choices:
            predicted = v + (v+2*correlation-mu*mu)/(p-1) - mu*mu/(p-1)**2
            assert predicted == stats(m*p)[1], (m, p)
            tail_checks.append([m, p])
        if m % 2:
            assert stats(2*m)[1] == 4*v
        assert stats(m*m)[1] == v
    report = {
        'status': 'PASS', 'squarefree_product_cap': 5000,
        'complete_counts_by_prime_count': dict(checked),
        'maximizers_within_cap': maximizers,
        'primorial_variances': {str(k): str(v) for k, v in base_values.items()},
        'odd_prime_pair_distribution_checks': odd_pair_checks,
        'large_new_prime_recurrence_checks': tail_checks,
        'false_coordinate_monotonicity_example': {str(n): str(stats(n)[1]) for n in [22, 33]},
    }
    (HERE/'sieve_verification.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
