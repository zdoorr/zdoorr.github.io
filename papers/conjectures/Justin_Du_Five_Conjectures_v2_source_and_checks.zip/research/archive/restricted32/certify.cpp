#include <bits/stdc++.h>
using namespace std;
struct P {uint16_t rem; uint8_t x;};
vector<array<uint32_t,32>> U(1<<16);
uint64_t nodes[16]={},pruned[16]={},leaves=0,ties=0;
uint64_t incumbent=48410; bool strict=true; chrono::steady_clock::time_point started;
vector<int> word; uint64_t visited=0;
uint64_t bound(const vector<P>&p){uint64_t b=0;for(auto s:p)b+=U[s.rem][s.x];return b;}
vector<P> step(const vector<P>&p,int d){vector<P> q;for(auto s:p)for(int y:{int(s.x)-d,int(s.x)+d}) if(y>=0&&y<32&&(s.rem>>(y%16)&1))q.push_back({uint16_t(s.rem^(1<<(y%16))),uint8_t(y^16)});return q;}
void dfs(const vector<P>&p,int depth,uint64_t b){
 nodes[depth]++;visited++;
 if(visited%1000000==0){cerr<<"progress nodes "<<visited<<" depth "<<depth<<" sec "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<" incumbent "<<incumbent<<" prefix ";for(auto d:word)cerr<<d<<",";cerr<<endl;}
 if(b<incumbent||(!strict&&b==incumbent)){pruned[depth]++;return;}
 if(depth==15){leaves++;if(p.size()>incumbent){incumbent=p.size();ties=0;cout<<"IMPROVE ";}else cout<<"TIE ";ties++;cout<<p.size()<<" ";for(auto d:word)cout<<d<<",";cout<<endl;return;}
 struct Child{int d;uint64_t b;vector<P>p;};vector<Child> children;
 for(int d=1;d<32;d++)if(d!=16){auto q=step(p,d);if(q.empty())continue;auto qb=bound(q);if(qb<incumbent||(!strict&&qb==incumbent)){pruned[depth+1]++;continue;}children.push_back({d,qb,move(q)});}
 sort(children.begin(),children.end(),[](const Child&a,const Child&b){return a.b>b.b;});
 for(auto&c:children){word.push_back(c.d);dfs(c.p,depth+1,c.b);word.pop_back();}
}
int main(int argc,char**argv){started=chrono::steady_clock::now();if(argc>1)strict=atoi(argv[1]);if(argc>2)incumbent=stoull(argv[2]);
 for(int x=0;x<32;x++)U[0][x]=1;
 for(int m=1;m<65536;m++)for(int x=0;x<32;x++)if(!(m>>(x%16)&1)){
 uint32_t best=0;for(int d=1;d<32;d++)if(d!=16){uint32_t sum=0;for(int y:{x-d,x+d})if(y>=0&&y<32&&(m>>(y%16)&1))sum+=U[m^(1<<(y%16))][y^16];best=max(best,sum);}U[m][x]=best;}
 vector<P>root;for(int x=0;x<32;x++)root.push_back({uint16_t(65535^(1<<(x%16))),uint8_t(x)});
 cerr<<"precompute sec "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<" root bound "<<bound(root)<<endl;
 vector<int>target={8,4,8,2,8,4,8,1,8,4,8,2,8,4,8};auto p=root;for(auto d:target)p=step(p,d);cout<<"TARGET_COUNT "<<p.size()<<endl;if(p.size()!=48410)return 2;
 dfs(root,0,bound(root));cout<<"COMPLETE max "<<incumbent<<" ties "<<ties<<" leaves "<<leaves<<" nodes "<<visited<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-started).count()<<endl;for(int i=0;i<16;i++)cout<<"depth "<<i<<" nodes "<<nodes[i]<<" pruned "<<pruned[i]<<endl;
}
