#include <bits/stdc++.h>
using namespace std;
int n=16; vector<array<uint16_t,16>> B; uint64_t nodes[17],pruned[17],leaves=0; uint64_t incumbent=13830; chrono::steady_clock::time_point start;
struct P{uint16_t rem; uint8_t last,first;};
uint64_t Q(array<uint64_t,16>&e){uint64_t q=0;for(int i=0;i<n;i++){q+=e[i]*e[i];}return q;}
void dfs(vector<P>& ps,int k,vector<int>& ds){
 nodes[k]++;
 array<uint64_t,16> e{};for(auto p:ps)e[p.first]+=B[p.rem][p.last];
 auto bound=Q(e); if(bound<incumbent){pruned[k]++;return;}
 if(k==n){leaves++;cout<<"QUALIFY "<<bound<<":";for(int d:ds)cout<<d<<",";cout<<" endpoints ";for(int i=0;i<n;i++)cout<<e[i]<<",";cout<<endl;return;}
 array<vector<P>,16> child;
 for(auto p:ps)for(int j=0;j<n;j++)if(p.rem>>j&1)child[abs(j-p.last)].push_back({uint16_t(p.rem^(1<<j)),uint8_t(j),p.first});
 for(int d=1;d<n;d++)if(!child[d].empty()){ds.push_back(d);dfs(child[d],k+1,ds);ds.pop_back();}
 if(k<=3){cerr<<"completed prefix ";for(int d:ds)cerr<<d<<",";cerr<<" sec "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;}
}
int main(int argc,char**argv){if(argc>1)n=atoi(argv[1]);if(argc>2)incumbent=stoull(argv[2]);start=chrono::steady_clock::now();B.resize(1<<n);for(int x=0;x<n;x++)B[0][x]=1;
 for(int mask=1;mask<(1<<n);mask++)for(int x=0;x<n;x++)if(!(mask>>x&1)){int best=0;for(int d=1;d<n;d++){int a=x-d,b=x+d,v=0;if(a>=0&&(mask>>a&1))v+=B[mask^(1<<a)][a];if(b<n&&(mask>>b&1))v+=B[mask^(1<<b)][b];best=max(best,v);}B[mask][x]=best;}
 cerr<<"precompute "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<" root bound:";for(int x=0;x<n;x++)cerr<<B[((1<<n)-1)^(1<<x)][x]<<",";cerr<<endl;
 vector<P> ps;for(int x=0;x<n;x++)ps.push_back({uint16_t(((1<<n)-1)^(1<<x)),uint8_t(x),uint8_t(x)});vector<int>ds;dfs(ps,1,ds);cout<<"completed threshold "<<incumbent<<" sec "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;for(int k=1;k<=n;k++)cout<<k<<" "<<nodes[k]<<" "<<pruned[k]<<endl;
}
