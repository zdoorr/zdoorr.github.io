发布包说明：本文所述数据输出统一收录于 ../results/。过程进度日志为节省篇幅未全部附入；完整结果的结束标志保留。运行命令与范围以包根目录 README.md 为准。

# Computational theorem: the saturated distance-16 class at n = 32

## Statement and scope
Let a realization of a distance word `(d_1,...,d_31)` be a permutation `(p_0,...,p_31)` of `{0,...,31}` with `|p_i-p_(i-1)|=d_i`. Count oriented permutations separately, including a permutation and its reversal or reflection when distinct.

Among all distance words containing sixteen occurrences of 16, the unique word of maximum multiplicity is

`(16,8,16,4,16,8,16,2,16,8,16,4,16,8,16,1,16,8,16,4,16,8,16,2,16,8,16,4,16,8,16)`.

Its multiplicity is **48,410**. This is a restricted-class theorem, not a global optimum theorem for arbitrary 32-point words. In particular, it does not bound any word with fewer than sixteen occurrences of 16.

## Reduction
The distance-16 edges are the disjoint matching `{j,j+16}`, `0 <= j < 16`. A simple Hamiltonian path cannot have consecutive distance-16 edges, since the second would revisit its previous vertex. Sixteen nonadjacent positions among 31 positions must be precisely positions 1,3,...,31. Therefore every realization in this class alternates a matching edge with an unconstrained bridge, beginning and ending with matching edges. Each matching pair is visited exactly once as a two-vertex block.

After traversing a block, record its actual endpoint `x` and the set `S` of unvisited matching-pair indices. A bridge of length `d` chooses an entry vertex `y=x-d` or `y=x+d`, provided `0 <= y < 32` and `j=y mod 16` belongs to `S`. The forced matching edge then exits at `y xor 16`, yielding state `(S\{j}, y xor 16)`. A bridge of length 16 is impossible because it would use the already visited current pair. The root contains one history at each of 32 possible endpoints, with its pair removed from `S`.

This reduction is a bijection: every original permutation in the class gives exactly one sequence of these transitions, and every complete transition sequence reconstructs one original permutation. It imposes no restriction on the number of odd bridges or any other bridge value.

## Admissible bound
Define `U(empty,x)=1`. For nonempty `S` and an endpoint whose pair is absent from `S`, define

`U(S,x) = max_(1 <= d <= 31) sum_(valid y=x±d) U(S\{y mod 16}, y xor 16)`.

Compute the recurrence in increasing numeric mask order, because deleting a bit always decreases the mask. For any single fixed suffix word, its number of completions from `(S,x)` is at most `U(S,x)`, by induction on `|S|`: group completions by their first entry vertex and apply the induction hypothesis. Different successor states may optimize different later suffixes, which can only make this recurrence an upper bound; it is not assumed to be an exact common-suffix optimum.

At a common bridge prefix, keep every compatible partial history. Summing `U` over histories bounds the number of realizations for every single extension of that prefix. Equivalently, merge equal states with their positive integer multiplicities and compute the weighted sum. The DFS explores every next bridge value having at least one compatible history. It prunes only when this upper bound is **strictly less** than the incumbent 48,410, retaining all potential equality cases. At depth 15 the number of histories is the exact realization count.

## Primary run
`certify.cpp` stores histories individually, precomputes `U`, verifies the displayed dyadic word has 48,410 realizations, and searches all common bridge prefixes. It orders children by decreasing bound, without removing any child on an unproved heuristic. `run.out` and `run.log` contain the output.

Observed result:

- Root bound: 319,194.
- Complete DFS: 139,575 visited nodes.
- Exactly one retained complete word, namely bridge word `(8,4,8,2,8,4,8,1,8,4,8,2,8,4,8)`.
- Maximum: 48,410; one equality word.
- Wall-clock runtime reported by executable: 14.5794 seconds.

The incumbent never increased. Thus no omitted prefix can equal or exceed 48,410, and the retained equality word is unique.

## Independent implementation
`verify.cpp` independently generates transitions by iterating unused pair indices and both orientations, rather than computing `x±d`. It constructs the bound by accumulating all transitions by their induced distance. It merges identical states with integer weights, traverses bridge values in ascending order, and again uses strict pruning. This checks a different state representation, transition enumeration, and traversal ordering. The independent run completed with maximum 48,410 and exactly one optimal word in 36.2615 seconds. It visited 4,099,789 prefixes including 3,960,214 strictly pruned prefixes, leaving exactly 139,575 unpruned nodes, matching the primary run. See `verify.out` for the full result.

## Arithmetic and reproducibility
A history has at most two transitions for any fixed next bridge. There are 32 roots and 15 bridges, so at any fixed prefix there are at most `32 * 2^15 = 1,048,576` histories. Every individual-state suffix bound is at most `2^15 = 32,768`. Bounds and weighted totals are summed in 64-bit unsigned integers; the table itself uses 32-bit unsigned integers. Hence no arithmetic overflow is possible in either implementation.

Compile and run with a standard C++17 compiler:

```
g++ -O3 -std=c++17 certify.cpp -o certify
./certify 1 > run.out 2> run.log
g++ -O3 -std=c++17 verify.cpp -o verify
./verify > verify.out 2> verify.log
```

The first command-line argument to `certify` must remain `1` to retain all equality cases. The second argument, if supplied, is the starting incumbent; the certified run uses the default 48,410. No input datasets or external libraries are required.
