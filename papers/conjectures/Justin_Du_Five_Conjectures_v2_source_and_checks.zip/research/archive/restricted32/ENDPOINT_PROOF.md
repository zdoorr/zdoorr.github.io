发布包说明：本文保留原研究论证。所述数据日志统一位于 ../results/；qbound、verify_witness、verify_small、verify_threshold、compare_independent 等原辅助程序未重复打包。入门独立重计数与阈值8交叉检查分别由包根目录的 smoke_test.py 和 check_threshold8.py 提供。所有本包重现命令以根目录 README.md 为准。

# Endpoint-quadratic branch-and-bound certificate

## Objective
For a permutation difference record A on [n], let e_A(i) count realizations ending at i, and define

Q(A) = 2 sum_i e_A(i)^2 + 2 sum_{i=1}^{n-1} e_A(i)e_A(i+1).

The computation uses starting counts instead. Reversing every realization gives start_A = end_reverse(A). Since reversal bijects all records, maximizing either version gives the same answer.

## Universally valid bound for a residual state
A residual state is (S,x), where S is the set of labels not yet visited and x is the current last label. Define

U(empty,x)=1,
U(S,x)=max_{1<=d<n} sum_{y in S: |y-x|=d} U(S minus {y},y).

For every fixed proposed remaining difference word, its number of completions from (S,x) is at most U(S,x). Proof is by induction on |S|: its first distance is one of the alternatives in the maximum, and its legal first steps have disjoint completions, each bounded by the induction hypothesis. The bound permits different optimal continuation words in different states, so need not be attainable simultaneously; only the upper-bound property is used.

## Bound for every extension of a prefix
At a record prefix w, the search stores ALL partial permutation paths realizing w. It retains their initial label s, last label x and remaining mask S. Repeated states are intentionally retained with multiplicity because they represent different partial paths.

For each initial label i, put b_i(w)=sum_{paths with initial i} U(S,x).
For every full record A extending w, its starting endpoint count satisfies start_A(i)<=b_i(w).

All coefficients of Q are nonnegative. Therefore Q(start_A)<=Q(b(w)). If Q(b(w))<=the incumbent, no descendant can improve the incumbent, and the entire prefix subtree is safely discarded.

Otherwise branch over every possible next distance d=1,...,n-1. Each stored path is extended to every unused label at that distance. This partitions all full records extending w by their next distance. At depth n the stored paths are precisely all realizations, U(empty,x)=1, and Q(b(w)) is the exact objective. The root has one path for each initial label. Thus completion of the recursion certifies the bound for EVERY record, not just sampled records or records with large total fiber.

## Arithmetic safety for n<=16
Every residual state with m unused labels has U<=2^m, since each next distance permits at most two next labels. Thus a stored uint16_t is sufficient: for admissible states m<=15, U<=32768. For each fixed initial label and prefix with k vertices, at most 2^(k-1) paths occur, each with U<=2^(n-k). Hence b_i<=2^(n-1)<=32768. All evaluations of Q fit in uint64_t (indeed Q<4*n*2^(2*n-2)<=2^36 at n=16). Node statistics also use uint64_t.

## Witness verification
verify_witness.py independently enumerates signed next-step choices for each dyadic record rather than using the matrix recurrence. It verifies Q(D2)=6, Q(D4)=30, Q(D8)=430, Q(D16)=48410. D16 has 430 realizations and endpoint vector

(50,36,24,35,15,12,18,25,25,18,12,15,35,24,36,50).

verify_small.py independently enumerates ALL permutations for each n<=9 and builds complete endpoint histograms by record. The resulting maxima are 2,6,8,30,16,48,72,430,144 for n=1,...,9. qbound 8 0 independently finds 430 without seeding the dyadic value.

## Scope
A certificate Q16<=48410 implies that every 32-label record of the form (2A,1,2reverse(B)), for arbitrary 16-label records A and B, has at most 48410 realizations. Indeed its fiber equals e_A^T T e_B, where T=2I+S+S^T is positive definite, so Cauchy-Schwarz bounds it by sqrt(Q(A)Q(B)). D32 attains this bound.

This does NOT bound arbitrary 32-label records, odd bridge lengths other than 1, or prove the dyadic endpoint bound for all powers of two. No scalar M16 assumption enters this endpoint proof.
