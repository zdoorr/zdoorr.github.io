#!/usr/bin/env python3
import json
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'results'; lines=(p/'threshold16.log').read_text().splitlines()
assert any(x.startswith('completed threshold 10591 ') for x in lines),'Threshold run must finish first'
profiles=[]
for line in lines:
 if not line.startswith('QUALIFY '):continue
 energy,rest=line[len('QUALIFY '):].split(':');record,vec=rest.split(' endpoints ')
 a=list(map(int,record.rstrip(',').split(',')));e=list(map(int,vec.rstrip(',').split(',')))
 assert sum(x*x for x in e)==int(energy)
 profiles.append({'record':a,'starting_endpoints':e,'E':int(energy)})
assert profiles
results=[]
for r in range(16):
 def count(u,v):
  if r==0:return 2*sum(x*y for x,y in zip(u,v))+sum(u[i]*v[i+1]+u[i+1]*v[i] for i in range(15))
  return sum(u[i]*v[i+d]+u[i+d]*v[i] for d in (r,r+1) for i in range(16-d))
 best=-1; pairs=[]
 for ia,a in enumerate(profiles):
  for ib,b in enumerate(profiles):
   c=count(a['starting_endpoints'],b['starting_endpoints'])
   if c>best:best=c;pairs=[]
   if c==best:pairs.append([ia,ib])
 results.append({'odd_bridge':2*r+1,'max_count_among_threshold_profiles':best,'maximizing_pairs':pairs})
out={'threshold':10591,'complete_qualifying_profiles':profiles,'bridge_results':results,'maximum':max(x['max_count_among_threshold_profiles'] for x in results)}
(p/'one_odd_bridge_certificate.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
