发布包说明：本文保留原研究论证。所述数据日志统一位于 ../results/；qbound、verify_witness、verify_small、verify_threshold、compare_independent 等原辅助程序未重复打包。入门独立重计数与阈值8交叉检查分别由包根目录的 smoke_test.py 和 check_threshold8.py 提供。所有本包重现命令以根目录 README.md 为准。

# Computer-assisted theorem: all one-odd-jump records on 32 labels

**Theorem.** Among all ordered absolute-adjacent-difference records of permutations of {1,...,32} having exactly one odd entry, the unique maximum-fiber record is D32=(2D16,1,2D16). Its fiber has size 48,410.

There is no assumption that the two halves are dyadic or recursively parity-split. This ranges over arbitrary realizable 16-label half-records and every possible odd bridge length. It remains a restricted theorem, not a global upper bound for unrestricted 32-label records.

## Certified 16-label facts

Write E(A)=sum_i e_A(i)^2 for endpoint energy. Exhaustive prefix branch-and-bound, with a proven componentwise endpoint bound, establishes:

1. E(A)<=13,830 for every 16-label record A.
2. D16 is the ONLY 16-label record with E(A)>=10,591. Consequently every other A satisfies E(A)<=10,590.
3. D16=(8,4,8,2,8,4,8,1,8,4,8,2,8,4,8), with endpoint vector
   (50,36,24,35,15,12,18,25,25,18,12,15,35,24,36,50).

The endpoint-energy maximum run took 133.258 seconds. The fixed-threshold enumeration took 179.315 seconds and visited 318,777,320 prefix nodes, pruning 295,561,443. Exactly one leaf qualified: D16, with E=13,830. All branch choices are covered; pruning compares a valid upper bound against a fixed threshold and never changes that threshold.

## Reduction of every one-odd-jump record

Even differences preserve parity. A realization with exactly one odd difference therefore visits one parity class, changes parity once, and visits the other parity class. Each class has 16 labels, so the change must occur between vertices 16 and 17. The two blocks exhaust their respective parity classes.

After rescaling each class to {1,...,16}, write the record as (2A,t,2reverse(B)), where t=2r+1 is odd and A,B are arbitrary 16-label records. Put u=e_A, v=e_B. Summing over both parity orders gives exactly

    F32(2A,t,2reverse(B)) = u^T K_r v,

where K_0=2I+Adj(1), and for r>=1, K_r=Adj(r)+Adj(r+1). Here Adj(d) has 1 at entries |i-j|=d and 0 elsewhere; d=16 contributes nothing.

Every row and column sum of K_r is at most 4, hence its Euclidean operator norm is at most 4. Therefore

    F32 <= 4 sqrt(E(A)E(B)).

If either A or B differs from D16, the certified energy gap gives

    F32 <= floor(sqrt(16*13830*10590)) = 48,408 < 48,410.

Equivalently, a competitor with count at least 48,410 would force BOTH half-energies to be at least ceil(48410^2/(16*13830))=10,591, and the complete threshold enumeration forces A=B=D16.

## Exact bridge check when both halves are D16

Direct integer evaluation of u^T K_r u yields the following values for bridge t=1,3,5,...,31, respectively:

    48410, 37790, 33220, 28500,
    24580, 25100, 25298, 23302,
    20062, 17138, 17112, 19648,
    17848, 14592, 12200, 5000.

Only bridge 1 attains 48,410. Since D16 is palindromic, this gives exactly D32, proving uniqueness within the stated class.

## Further consequences

The endpoint quadratic Q(A)=2sum e_i^2+2sum e_i e_(i+1) is at most 4E(A), because 2 e_i e_(i+1)<=e_i^2+e_(i+1)^2. Thus every non-D16 record has Q(A)<=42,360, whereas Q(D16)=48,410. D16 is therefore also the UNIQUE Q-maximizer on 16 labels. This is stronger than the original Q-only certificate, which pruned equality and did not itself classify maximizers.

## Reproducible artifacts

- ENDPOINT_PROOF.md: complete proof of residual-state and endpoint-vector bounds, exhaustive coverage and arithmetic safety.
- qbound.cpp, q16.log: direct all-profile Q16 maximum certificate.
- ebound.cpp, e16.log: direct all-profile E16 maximum certificate.
- threshold.cpp, threshold16.log: complete fixed-threshold E>=10591 enumeration.
- evaluate_bridges.py, one_odd_bridge_certificate.json: exact bridge calculations.
- verify_witness.py, witness.json: independent signed-walk witness verification.
- verify_small.py, small_exact.json, crosscheck.json: full-permutation cross-checks through n=9.
- verify_threshold.py, threshold_crosscheck.json: fixed-threshold search agrees on all 50 qualifying profiles in an independent full 8! permutation enumeration at threshold 25.

Compile C++ programs with g++ -O3 -std=c++17. The decisive commands are ./ebound 16 13830 and ./threshold 16 10591, followed by python evaluate_bridges.py. No random sampling, floating-point arithmetic or unproved endpoint-shape assumption enters the certificate.

## Independent full-size verification completed

A separately implemented half-start checker, halfstart_check.cpp, starts only at labels 0 through 7 and recovers the other starting counts by label complementation. It uses the bound 2 sum_{i=0}^7 b_i^2, computes residual U by unused-vertex/reflected-partner grouping, and generates search transitions by plus/minus distance, differently from the original implementation.

It terminated with the explicit line:

    DONE hits 1 nodes 318777320 seconds 110.754

Its sole qualifying record, exact endpoint vector, energy, and total prefix-node count all agree with the original full-start search. compare_independent.py verified these equalities after checking that both runs had completed; independent_crosscheck.json records the checks. This is an independent implementation check at the full n=16 size, in addition to the small-size permutation enumeration tests.
