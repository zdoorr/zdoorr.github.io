发布包说明：本文保留原研究论证。所述数据日志统一位于 ../results/；qbound、verify_witness、verify_small、verify_threshold、compare_independent 等原辅助程序未重复打包。入门独立重计数与阈值8交叉检查分别由包根目录的 smoke_test.py 和 check_threshold8.py 提供。所有本包重现命令以根目录 README.md 为准。

# Exhaustive endpoint-energy threshold enumeration

threshold.cpp uses the same valid endpoint upper vector as qbound.cpp / ebound.cpp. Its threshold is fixed throughout the search. It prunes only if sum_i b_i^2 < threshold, and reports EVERY full record with starting-endpoint energy at least threshold. In particular equality is never pruned. No incumbent update occurs. Hence completion enumerates every record satisfying the threshold, not just successive record holders.

At threshold 10591 this has the following application. For every odd bridge t=2r+1, a 32-label record containing exactly one odd jump must split into two 16-vertex parity blocks. Its count is u^T K_r v, where u,v are endpoint vectors of arbitrary 16-label records (with a reversal convention on the second), K_0=2I+adjacency(distance 1), and K_r=adjacency(distance r)+adjacency(distance r+1) for r>=1. All row sums and column sums are at most 4, so ||K_r||_2<=4. The certified Emax16=13830 therefore implies

    u^T K_r v <= 4 sqrt(E(u)E(v)) <= 4 sqrt(13830 E(u)).

A count at least 48410 consequently requires BOTH energies to be at least

    ceil(48410^2 / (16*13830)) = ceil(117176405/11064) = 10591.

Thus the complete threshold output reduces ALL one-odd-jump 32-label contenders to pairs of its finitely many records. If that output consists of D16 alone, only its 16 odd bridge lengths need checking to prove extremality and classify equality within the entire one-odd-jump class. If other profiles occur, every pair and all 16 kernels must be checked instead.
