#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <vector>
using namespace std;
using State=pair<uint32_t,uint64_t>; // key = 32 * unused mask + endpoint; weight counts histories.
array<vector<uint32_t>,32> B;
uint64_t calls=0,discarded=0,solutions=0,maxcount=48410;
vector<int> prefix;
vector<State> compress(vector<State> a){sort(a.begin(),a.end());vector<State>b;for(auto t:a){if(!b.empty()&&b.back().first==t.first)b.back().second+=t.second;else b.push_back(t);}return b;}
void search(const vector<State>&a,int left){
 ++calls;uint64_t upper=0;for(auto [key,w]:a)upper+=w*B[key%32][key/32];if(upper<maxcount){++discarded;return;}
 if(!left){uint64_t total=0;for(auto [key,w]:a)total+=w;if(total>maxcount){maxcount=total;solutions=0;}++solutions;cout<<"OPTIMAL "<<total<<":";for(int d:prefix)cout<<" "<<d;cout<<endl;return;}
 array<vector<State>,32> children;
 for(auto [key,w]:a){unsigned mask=key/32,x=key%32;for(unsigned j=0;j<16;j++)if(mask&(1u<<j))for(unsigned orientation=0;orientation<2;orientation++){unsigned entry=j+16*orientation;int d=abs(int(entry)-int(x));unsigned exit=entry^16;children[d].push_back({32*(mask^(1u<<j))+exit,w});}}
 for(int d=1;d<32;d++)if(!children[d].empty()){prefix.push_back(d);search(compress(move(children[d])),left-1);prefix.pop_back();}
}
int main(){auto start=chrono::steady_clock::now();for(auto&v:B){v.resize(65536);v[0]=1;}
 for(unsigned mask=1;mask<65536;mask++)for(unsigned x=0;x<32;x++)if(!(mask&(1u<<(x%16)))){array<uint32_t,32> totals{};for(unsigned j=0;j<16;j++)if(mask&(1u<<j))for(unsigned orient=0;orient<2;orient++){unsigned y=j+16*orient;totals[abs(int(x)-int(y))]+=B[y^16][mask^(1u<<j)];}B[x][mask]=*max_element(totals.begin(),totals.end());}
 vector<State>root;for(unsigned x=0;x<32;x++)root.push_back({32*(65535^(1u<<(x%16)))+x,1});search(root,15);
 cout<<"COMPLETE maximum "<<maxcount<<" solutions "<<solutions<<" calls "<<calls<<" discarded "<<discarded<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-start).count()<<endl;
}
