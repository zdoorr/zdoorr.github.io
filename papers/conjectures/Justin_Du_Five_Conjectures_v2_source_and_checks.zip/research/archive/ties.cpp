#include <array>
#include <vector>
#include <iostream>
#include <chrono>
#include <cstdint>
#include <algorithm>
using namespace std;
constexpr int N=16, FULL=65535, TARGET=215;
static uint16_t u[65536][16];
struct State {int unused,at;};
static uint64_t nodes=0,ties=0;static array<int,15> word;static auto begun=chrono::steady_clock::now();
void search(const vector<State>& ensemble,int depth){
 ++nodes;int upper=0;for(const auto& s:ensemble)upper+=u[s.unused][s.at];if(upper<TARGET)return;
 if(depth==15){if(ensemble.size()>=TARGET){++ties;cout<<"FIBER "<<ensemble.size()*2<<" WORD";for(int d:word)cout<<" "<<d;cout<<endl;}return;}
 for(int d=1;d<N;++d){vector<State> next;next.reserve(ensemble.size());for(const auto&s:ensemble){int a=s.at-d,b=s.at+d;if(a>=0&&(s.unused&(1<<a)))next.push_back({s.unused^(1<<a),a});if(b<N&&(s.unused&(1<<b)))next.push_back({s.unused^(1<<b),b});}if(!next.empty()){word[depth]=d;search(next,depth+1);}if(depth==0)cerr<<"ROOT_DONE "<<d<<" nodes "<<nodes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-begun).count()<<endl;}
}
int main(){
 for(int x=0;x<N;++x)u[0][x]=1;
 for(int mask=1;mask<=FULL;++mask)for(int x=0;x<N;++x)if(!(mask&(1<<x))){int best=0;for(int bits=mask;bits;bits&=bits-1){int y=__builtin_ctz((unsigned)bits),z=2*x-y;int v=u[mask^(1<<y)][y];if(z>=0&&z<N&&(mask&(1<<z)))v+=u[mask^(1<<z)][z];best=max(best,v);}u[mask][x]=best;}
 vector<State> initial;for(int x=0;x<N/2;++x)initial.push_back({FULL^(1<<x),x});search(initial,0);cout<<"DONE ties "<<ties<<" nodes "<<nodes<<" seconds "<<chrono::duration<double>(chrono::steady_clock::now()-begun).count()<<endl;
}
