"""Exact small-size fiber counts, endpoint recurrences and archived witnesses."""
from collections import Counter
from decimal import Decimal, getcontext
from pathlib import Path
import importlib.util
import itertools
import json

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]


def delta(p):
    return tuple(abs(a-b) for a, b in zip(p, p[1:]))


def dyadic(n):
    if n == 1:
        return ()
    h = tuple(2*x for x in dyadic(n//2))
    return h+(1,)+h


def endpoint_counts(word):
    n = len(word)+1
    ends = [0]*n
    full = (1 << n)-1

    def visit(x, mask, depth):
        if mask == full:
            ends[x] += 1
            return
        d = word[depth]
        for y in (x-d, x+d):
            if 0 <= y < n and not (mask >> y)&1:
                visit(y, mask | (1 << y), depth+1)

    for x in range(n):
        visit(x, 1 << x, 0)
    return ends


def double(e):
    n = len(e)
    b = [[0]*n for _ in range(n)]
    for i in range(n):
        for a in range(n):
            w = e[i][a]
            if w:
                for j in range(n):
                    b[i][j] += w*(e[a][j]+(e[a-1][j] if a else 0))
    out = [[0]*(2*n) for _ in range(2*n)]
    for i in range(n):
        for j in range(n):
            out[2*i][2*j+1] = b[i][j]
            out[2*j+1][2*i] = b[i][j]
    return out


def main():
    catalogue_path = HERE/'archive/catalogue.json'
    catalogue = json.loads(catalogue_path.read_text(encoding='utf-8-sig'))
    small = []
    for n in range(1, 9):
        counts = Counter(delta(p) for p in itertools.permutations(range(1, n+1)))
        maximum = max(counts.values())
        maximizers = sorted(w for w, c in counts.items() if c == maximum)
        row = next(r for r in catalogue if r['n'] == n)
        assert row['maximum_fiber'] == maximum
        assert sorted(tuple(x) for x in row['maximizers']) == maximizers
        small.append({'n': n, 'records': len(counts), 'maximum': maximum,
                      'maximizer_count': len(maximizers)})
    witnesses = []
    for row in catalogue:
        if row['n'] > 16:
            continue
        for w in row['maximizers']:
            actual = sum(endpoint_counts(tuple(w)))
            assert actual == row['maximum_fiber']
        witnesses.append({'n': row['n'], 'recounted_maximizers': len(row['maximizers']),
                          'archived_maximum': row['maximum_fiber'],
                          'global_optimum_reenumerated_now': row['n'] <= 8})
    e = [[1]]
    candidate = []
    while len(e) <= 128:
        n = len(e)
        r = [sum(row) for row in e]
        assert r == r[::-1]
        if n <= 32:
            assert endpoint_counts(dyadic(n)) == r
        candidate.append({'n': n, 'fiber': sum(r), 'endpoint_counts': r})
        if n == 128:
            break
        e = double(e)
    u = (4,2,4,1,4,2)
    ends = endpoint_counts(u)
    assert ends == [0,0,0,6,0,0,0]
    glued = tuple(2*x for x in u)+(1,)+tuple(2*x for x in u[::-1])
    assert sum(endpoint_counts(glued)) == 72
    getcontext().prec = 40
    f128 = candidate[-1]['fiber']
    lower = (Decimal(f128)/128) ** (Decimal(1)/128)
    report = {'status': 'PASS', 'complete_enumeration': small,
              'archived_catalogue_witness_recounts': witnesses,
              'candidate_recurrence': candidate,
              'general_growth_constant_lower_from_128': str(lower),
              'endpoint_concentration_example': {'word': u, 'ends': ends, 'glued_fiber': 72}}
    (HERE/'permutation_verification.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'small_table': small,
                      'candidate_totals': [[r['n'], r['fiber']] for r in candidate],
                      'growth_lower_bound': str(lower)}))


if __name__ == '__main__':
    main()
