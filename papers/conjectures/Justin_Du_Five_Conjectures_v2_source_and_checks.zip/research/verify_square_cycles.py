"""Construct and independently verify a bounded set of deletion necklaces.

Endpoint rotations are a search procedure, not an unbounded existence proof.
"""
from collections import deque
from hashlib import sha256
from math import isqrt
from pathlib import Path
import gzip
import json
import time

HERE = Path(__file__).resolve().parent
SEED32 = (4,21,28,8,1,15,10,26,23,2,14,22,27,9,16,20,29,7,18,31,5,11,25,24,12,13,3,6,30,19,17,32)


def square(x):
    return isqrt(x)**2 == x


def verify(cycle, n, deleted=None):
    wanted = set(range(1, n+1)) - ({deleted} if deleted else set())
    assert len(cycle) == len(wanted) == len(set(cycle))
    assert set(cycle) == wanted
    assert all(square(cycle[i-1]+cycle[i]) for i in range(len(cycle)))


def adjacency(n):
    return {v: tuple(s*s-v for s in range(2, isqrt(2*n)+1) if 1 <= s*s-v <= n and s*s-v != v)
            for v in range(1, n+1)}


def close(path, adj, limit=20000):
    path = tuple(path)
    if square(path[0]+path[-1]):
        return path, 1
    queue = deque([path])
    seen = {min(path, path[::-1])}
    while queue and len(seen) <= limit:
        path = queue.popleft()
        for oriented in (path, path[::-1]):
            positions = {v: i for i, v in enumerate(oriented)}
            for neighbor in adj[oriented[-1]]:
                i = positions.get(neighbor)
                if i is None or i >= len(path)-2:
                    continue
                if i == 0:
                    return oriented, len(seen)
                rotated = oriented[:i+1] + oriented[i+1:][::-1]
                canonical = min(rotated, rotated[::-1])
                if canonical in seen:
                    continue
                if square(rotated[0]+rotated[-1]):
                    return rotated, len(seen)+1
                seen.add(canonical)
                queue.append(rotated)
    raise RuntimeError(f'Rotation search did not finish within {limit} states')


def main():
    started = time.monotonic()
    verify(SEED32, 32)
    cycles = {32: SEED32}
    max_states = 0
    for n in range(33, 121):
        old = cycles[n-1]
        adj = adjacency(n)
        for u in adj[n]:
            k = old.index(u)
            path = old[k+1:] + old[:k+1] + (n,)
            try:
                cycle, states = close(path, adj)
                break
            except RuntimeError:
                continue
        else:
            raise RuntimeError(f'No ordinary cycle constructed for n={n}')
        verify(cycle, n)
        cycles[n] = cycle
        max_states = max(max_states, states)
    witnesses = []
    for n in range(71, 121):
        cycle = cycles[n]
        adj = adjacency(n)
        for d in range(1, n+1):
            k = cycle.index(d)
            path = cycle[k+1:] + cycle[:k]
            result, states = close(path, adj)
            verify(result, n, d)
            witnesses.append({'n': n, 'd': d, 'cycle': result})
            max_states = max(max_states, states)
        if n % 10 == 0:
            print(f'VERIFIED THROUGH {n}: {len(witnesses)} deletion cycles', flush=True)
    # Check every degree obstruction used in the proof of the sharp threshold.
    obstructions = []
    for n in range(4, 71):
        v = 1 if n <= 14 else 2 if n <= 22 else 18 if n <= 45 else 32 if n <= 48 else 49 if n == 49 else 50
        neighbors = adjacency(n)[v]
        assert len(neighbors) <= 2
        obstructions.append({'n': n, 'v': v, 'neighbors': neighbors})
    assert min(map(len, adjacency(71).values())) == 3
    for n in range(71, 1001):
        assert min(map(len, adjacency(n).values())) >= 3
    # Independent graph-free pass over the saved witnesses.
    for witness in witnesses:
        verify(witness['cycle'], witness['n'], witness['d'])
    certificate = HERE/'square_deletion_cycles_71_120.json.gz'
    with gzip.open(certificate, 'wt', encoding='utf-8', compresslevel=9) as stream:
        json.dump(witnesses, stream, separators=(',', ':'))
    report = {'status': 'PASS', 'n_min': 71, 'n_max': 120,
              'deletion_cases': len(witnesses), 'max_observed_rotation_states': max_states,
              'uniform_termination_claim': False, 'seconds': round(time.monotonic()-started, 3),
              'certificate': certificate.name, 'sha256': sha256(certificate.read_bytes()).hexdigest(),
              'sharp_threshold_obstructions': obstructions}
    (HERE/'square_verification.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in report.items() if k != 'sharp_threshold_obstructions'}))


if __name__ == '__main__':
    main()
