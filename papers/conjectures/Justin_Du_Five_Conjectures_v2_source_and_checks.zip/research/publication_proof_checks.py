"""Separate exact checks for the pre-publication proof review.

This does not rerun the n=16 archived searches. Polynomial identities below
verify the written continuous-domain arguments, not a finite grid of primes.
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import lru_cache
from itertools import permutations
from math import isqrt
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

class P:
    def __init__(self, terms):
        if not isinstance(terms, dict):
            terms = {(0,0,0): F(terms)}
        self.a = {k:F(v) for k,v in terms.items() if v}
    def __add__(self, b):
        b = b if isinstance(b,P) else P(b)
        a = dict(self.a)
        for k,v in b.a.items(): a[k] = a.get(k,0)+v
        return P(a)
    __radd__ = __add__
    def __neg__(self): return P({k:-v for k,v in self.a.items()})
    def __sub__(self,b): return self+-coerce(b)
    def __rsub__(self,b): return coerce(b)+-self
    def __mul__(self,b):
        b=coerce(b); a=defaultdict(F)
        for e,c in self.a.items():
            for f,d in b.a.items(): a[tuple(x+y for x,y in zip(e,f))]+=c*d
        return P(a)
    __rmul__ = __mul__
    def __pow__(self,k):
        a=P(1)
        for _ in range(k): a=a*self
        return a
    def derivative(self,k):
        out={}
        for e,c in self.a.items():
            if e[k]:
                f=list(e); f[k]-=1; out[tuple(f)] = c*e[k]
        return P(out)
    def __eq__(self,b): return self.a==coerce(b).a

def coerce(x): return x if isinstance(x,P) else P(x)

def polynomial_review():
    x,y,z=[P({tuple(int(i==j) for i in range(3)):1}) for j in range(3)]
    f2=1+3*(x+y)+7*x*y-(1+x)**2*(1+y)**2
    assert f2.derivative(0)-y*(1-3*y)==(1-2*x)*(1+y)**2
    assert f2.derivative(1)-(F(1,2)+2*x-F(5,2)*x*x)==2*(F(1,4)-y)*(1+x)**2
    # The latter lower bound is >=1/2, since x(2-5x/2)>=0 on [0,1/2].
    h=F(5,2)+F(13,2)*(x+y)+F(33,2)*x*y-F(9,4)*(1+x)**2*(1+y)**2
    assert h.derivative(0)-(F(7,8)+F(21,4)*y-F(45,8)*y*y)==F(9,2)*(F(1,4)-x)*(1+y)**2
    f3=1+3*(x+y+z)+7*(x*y+x*z+y*z)+15*x*y*z-(1+x)**2*(1+y)**2*(1+z)**2
    lower=F(1,2)+F(11,8)*(y+z)+F(75,32)*y*z
    nonnegative=(2*(F(1,4)-x)*(1+y)**2*(1+z)**2
                 +F(5,2)*(y*(F(1,4)-y)+z*(F(1,4)-z))
                 +5*y*z*(F(1,2)-y-z)+F(5,2)*y*z*(F(1,16)-y*z))
    assert f3.derivative(0)-lower==nonnegative
    return {'derivative_identities':4,
            'continuous_domain':'F2: 0<x<=1/2, 0<y<=1/4; H and F3: variables in (0,1/4]. Each remainder is nonnegative throughout its stated box.',
            'strictness':'The displayed lower bounds are strictly positive on the required domains; ordered distinct-prime endpoint bounds give the unique equality cases.'}

def pruning_review(n):
    counts=defaultdict(lambda:[0]*n)
    for p in permutations(range(n)):
        word=tuple(abs(a-b) for a,b in zip(p,p[1:]))
        counts[word][p[0]]+=1
    energies={w:sum(c*c for c in v) for w,v in counts.items()}
    maximum=max(energies.values())
    second=max([v for v in energies.values() if v<maximum],default=0)
    threshold=second+1
    expected={w:e for w,e in energies.items() if e>=threshold}
    @lru_cache(None)
    def bound(mask,x):
        if not mask: return 1
        groups=defaultdict(int)
        for y in range(n):
            if mask>>y&1: groups[abs(y-x)]+=bound(mask^(1<<y),y)
        return max(groups.values(),default=0)
    full=(1<<n)-1
    found={}; nodes=0
    def visit(states, word):
        nonlocal nodes
        nodes+=1
        upper=[0]*n
        for mask,x,origin in states: upper[origin]+=bound(mask,x)
        energy=sum(x*x for x in upper)
        if energy<threshold: return
        if len(word)==n-1:
            found[word]=energy
            return
        children=defaultdict(list)
        for mask,x,origin in states:
            for y in range(n):
                if mask>>y&1: children[abs(y-x)].append((mask^(1<<y),y,origin))
        for d,states in children.items(): visit(states,word+(d,))
    visit([(full^(1<<x),x,x) for x in range(n)],())
    assert found==expected
    return {'n':n,'global_energy':maximum,'nonmaximum_energy':second,
            'threshold':threshold,'qualifying_words':len(found),'nodes':nodes,
            'matches_unpruned_permutation_enumeration':True}

def rotation_review():
    old=json.loads((HERE/'extensions_v2_verification.json').read_text(encoding='utf-8'))
    c=tuple(old['square']['cycle71'])
    edge=lambda u,v: isqrt(u+v)**2==u+v
    assert sorted(c)==list(range(1,72)) and all(edge(c[i],c[(i+1)%71]) for i in range(71))
    k=c.index(1); initial=c[k+1:]+c[:k]
    frontier={min(initial,initial[::-1])}; seen=set(frontier); layers=[]
    for depth in range(5):
        closures=[p for p in frontier if edge(p[0],p[-1])]
        layers.append({'depth':depth,'new_paths':len(frontier),'closures':len(closures)})
        if closures:
            assert depth==4
            break
        nxt=set()
        for p in frontier:
            for q in (p,p[::-1]):
                for i in range(1,len(q)-2):
                    if edge(q[-1],q[i]):
                        rotated=q[:i+1]+q[:i:-1]
                        assert len(rotated)==70 and len(set(rotated))==70
                        assert all(edge(a,b) for a,b in zip(rotated,rotated[1:]))
                        canonical=min(rotated,rotated[::-1])
                        if canonical not in seen: nxt.add(canonical)
        seen.update(nxt); frontier=nxt
    return {'specified_cycle_deleted_label':1,'minimum_endpoint_rotations':4,
            'independent_level_expansion':layers,
            'scope':'This specified starting path, not all starting Hamiltonian cycles.'}

def constants_review():
    pi_lo,pi_hi=F(314159,100000),F(314160,100000)
    rho=4-(pi_lo/17)**2+(pi_hi/17)**4/12
    assert rho<F(1983,500)
    val=F(1983**2*13830*10590,500**2)
    assert 47996**2<=val<47997**2
    threshold=F(48410**2*500**2,1983**2*13830)
    assert 10773<threshold<10774
    t=8; r=F(2,5)**t*(F(t,5)/(1-F(2,5)**t)+F(t*t,5)/(1-F(2,5)**t)**2)
    assert r<F(1,100)
    assert F(3,4)*F(94,169)+F(1,4)*F(4,9)==F(1607,3042)
    assert F(1607,3042)-F(9,20)==F(2381,30420)
    assert F(2381*3-6084,30420)>0
    assert F(729,2197)<F(1,3)
    return {'spectral_integer_upper':47996,'necessary_half_energy':10774,
            'path_error_R8':str(r),'branch_family_infinite_tail_begins_at_m':3}

if __name__=='__main__':
    report={'polynomial_identities':polynomial_review(),
            'archived_pruning_method_small_order_checks':[pruning_review(n) for n in (2,4,6,8)],
            'rotation_counterexample':rotation_review(), 'rational_constants':constants_review(),
            'new_infinite_assertions_reviewed':[
                'Sieve: CRT gap configurations, both odd-prime classes, strict monotonicity, doubling and equality.',
                'Square graph: all admissible square sums, self-edge removal, degree bounds and both endpoint rotations.',
                'Fibers: unique translation, distinct block orientations, complete interval partition and antichain injection.',
                'Dyadic: path-chain operator norms, integer rounding, exact old energy-certificate hypothesis and one-odd-entry scope.',
                'Trees: independent-triple coefficient, fixed-tree Taylor remainder, one positive crossover, total variance and all m>=1.'
            ],
            'scope_notes':[
                'No claim that any general conjecture has been proved.',
                'Third manuscript is an open extremal problem, not an asserted universal formula.',
                'Order-32 bound applies only to the one-odd-entry class; it depends on archived n=16 exhaustive energy computation.',
                'Old n=16 computations and large historical tree enumerations were not rerun.',
                'AI internal proof review and exact checks do not constitute independent peer review.'
            ],'status':'PASS'}
    report['source_hashes']={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT/'papers').glob('*/*.tex'))}
    (HERE/'publication_proof_review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':'PASS','certificate_crosschecks':report['archived_pruning_method_small_order_checks'],
                     'rotation_depth':report['rotation_counterexample']['minimum_endpoint_rotations'],
                     'exact_derivative_identities':4},ensure_ascii=False))
