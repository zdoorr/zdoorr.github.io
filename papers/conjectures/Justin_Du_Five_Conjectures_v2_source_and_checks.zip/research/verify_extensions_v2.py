"""Bounded, exact checks of the new local theorems in revision 2.

No theorem is inferred from a cutoff. All infinite assertions have written
proofs in the papers; these independent finite checks catch formula errors.
"""
from collections import Counter, deque
from fractions import Fraction as F
from itertools import combinations, permutations
from math import gcd, isqrt, comb, prod
from pathlib import Path
import json
import time
import verify_square_cycles as sq
import verify_permutations as perm
import verify_trees as tr

HERE = Path(__file__).resolve().parent


def gaps(n):
    rr = [x for x in range(1,n) if gcd(x,n)==1]
    return [b-a for a,b in zip(rr,rr[1:])]+[n+rr[0]-rr[-1]]


def sieve_checks():
    primes = [3,5,7,11,13,17,19,23,29,31,37,41,43]
    pair_best = (F(-1),None)
    for p,q in combinations(primes,2):
        n=p*q; gg=gaps(n); h=(p-1)*(q-1)
        v=F(sum(g*g for g in gg),h)-F(n,h)**2
        x,y=F(1,p-1),F(1,q-1)
        formula=1+3*(x+y)+7*x*y-((1+x)*(1+y))**2
        assert v==formula
        if v>pair_best[0]: pair_best=(v,n)
    triple_best = (F(-1),None)
    triple_no3_best = (F(-1),None)
    for p,q,r in combinations(primes,3):
        n=p*q*r; gg=gaps(n); h=(p-1)*(q-1)*(r-1)
        counts=Counter(gg); a1=(p-2)*(q-2)*(r-2)
        a4,a5=(2,2) if p==3 else (6,0)
        assert counts[1]==a1 and counts[4]==a4 and counts[5]==a5
        assert max(gg)<=5 and (p==3 or max(gg)<=4)
        assert sum(g*g for g in gg)==5*n-6*h+2*a1+2*a4+6*a5
        v=F(sum(g*g for g in gg),h)-F(n,h)**2
        xx=[F(1,t-1) for t in (p,q,r)]
        x,y,z=xx
        formula=1+3*(x+y+z)+7*(x*y+x*z+y*z)+(19 if p==3 else 15)*x*y*z-prod(1+t for t in xx)**2
        assert v==formula
        if v>triple_best[0]: triple_best=(v,n)
        if p!=3 and v>triple_no3_best[0]: triple_no3_best=(v,n)
    assert pair_best==(F(39,64),15)
    assert triple_best==(F(853,768),105)
    assert triple_no3_best==(F(7171,11520),385)
    return {'odd_primes_through':43,'pairs':comb(len(primes),2),'triples':comb(len(primes),3),
            'maximum_odd_pair':[str(pair_best[0]),pair_best[1]],
            'maximum_odd_triple':[str(triple_best[0]),triple_best[1]],
            'maximum_odd_triple_without_3':[str(triple_no3_best[0]),triple_no3_best[1]],
            'three_factor_global_target':'39/16','even_four_factor_target':'853/192'}


def edge_formula(n):
    return sum((s*s-1)//2 if s*s<=n+1 else (2*n+1-s*s)//2
               for s in range(2,isqrt(2*n)+1))


def rotate_once(path,adj):
    for oriented in (path,path[::-1]):
        pos={v:i for i,v in enumerate(oriented)}
        for neighbor in adj[oriented[-1]]:
            i=pos.get(neighbor)
            if i is not None and 0<i<len(path)-2:
                yield oriented[:i+1]+oriented[i+1:][::-1]


def min_repair(path,adj):
    queue=deque([(path,0)]); seen={min(path,path[::-1])}
    while queue:
        p,depth=queue.popleft()
        if sq.square(p[0]+p[-1]): return p,depth,len(seen)
        for q in rotate_once(p,adj):
            key=min(q,q[::-1])
            if key not in seen:
                seen.add(key); queue.append((q,depth+1))
        assert len(seen)<20000
    raise AssertionError('No repair witness')


def square_checks():
    for n in range(1,201):
        direct=sum(sq.square(a+b) for a in range(1,n+1) for b in range(a+1,n+1))
        assert direct==edge_formula(n)
    cycle=sq.SEED32
    for n in range(33,72):
        adj=sq.adjacency(n)
        for u in adj[n]:
            k=cycle.index(u); path=cycle[k+1:]+cycle[:k+1]+(n,)
            try: candidate,_=sq.close(path,adj); break
            except RuntimeError: pass
        else: raise AssertionError(n)
        sq.verify(candidate,n); cycle=candidate
    histogram=Counter(); examples=[]
    for d in range(1,72):
        k=cycle.index(d); path=cycle[k+1:]+cycle[:k]
        repaired,depth,states=min_repair(path,adj)
        sq.verify(repaired,71,d)
        histogram[depth]+=1
        if depth>1:
            assert not sq.square(path[0]+path[-1])
            assert not any(sq.square(p[0]+p[-1]) for p in rotate_once(path,adj))
            examples.append({'deleted':d,'initial_endpoints':[path[0],path[-1]],'minimum_rotations':depth,
                             'states':states,'initial_path':path,'repaired_cycle':repaired})
    assert examples
    ns=sq.adjacency(71)[50]
    assert ns==(14,31,71) and not any(sq.square(a+b) for a,b in combinations(ns,2))
    return {'edge_formula_checked_through':200,'cycle71':cycle,'minimum_rotation_depth_histogram':dict(sorted(histogram.items())),
            'one_rotation_failure':examples[0],'deletion50_has_no_direct_shortcut_in_any_cycle':True,
            'edge_count_examples':{str(n):edge_formula(n) for n in (71,120,1000)}}


def record_checks():
    exact4=Counter(perm.delta(p) for p in permutations(range(1,5)))
    families=0
    for n in range(4,17):
        for a in range(2,n-1):
            b=n-a
            for t in range(1,n):
                word=(1,)*(a-1)+(t,)+(1,)*(b-1)
                actual=sum(perm.endpoint_counts(word))
                assert actual==2*sum(t==v for v in (1,a,b,n-1))
                families+=1
    for n in range(2,9):
        grouped=Counter()
        parity_vectors={q:set() for q in range(1,n)} if n%2==0 else None
        for p in permutations(range(1,n+1)):
            w=perm.delta(p)
            grouped[(w,p[0],p[-1])]+=1
            assert gcd(*w)==1
            run=[]
            for d in w:
                if run and run[-1][0]==d: run[-1][1]+=1
                else: run.append([d,1])
            assert all(d*length<=n-1 for d,length in run)
            if parity_vectors is not None:
                lengths=[1]
                for a,b in zip(p,p[1:]):
                    if (a-b)%2: lengths.append(1)
                    else: lengths[-1]+=1
                parity_vectors[len(lengths)-1].add(tuple(lengths))
        byword=Counter()
        for (w,s,t),v in grouped.items():
            assert v<=comb(n-1,(n-1)//2)
            byword[w]+=v
        for w,v in byword.items():
            runs=1+sum(a!=b for a,b in zip(w,w[1:]))
            assert v<=2**runs
        if parity_vectors is not None:
            m=n//2
            for q,vs in parity_vectors.items():
                t=(q+1)//2
                expected=comb(m-1,t-1)**2 if q%2 else comb(m-1,t)*comb(m-1,t-1)
                assert len(vs)==expected,(n,q,len(vs),expected)
    cat=json.loads((HERE/'archive/catalogue.json').read_text(encoding='utf-8-sig'))
    w13=next(tuple(w) for row in cat if row['n']==13 for w in row['maximizers'] if 1 not in w)
    assert sum(perm.endpoint_counts(w13))==40
    return {'two_interval_family_cases':families,'all_records_restrictions_checked_through':8,
            'analytic_four_label_table':[{'word':w,'fiber':v} for w,v in sorted(exact4.items())],
            'archived_n13_maximizer_without_distance1':w13,'fresh_recount':40}


def dyadic_checks():
    u=perm.endpoint_counts(perm.dyadic(16)); energy=sum(x*x for x in u)
    assert energy==13830
    pi_lo,pi_hi=F(314159,100000),F(314160,100000)
    rho_upper=4-(pi_lo/17)**2+(pi_hi/17)**4/12
    rational=F(1983,500)
    assert rho_upper<rational
    other_energy=10590; target=48410
    improved=isqrt((1983**2*energy*other_energy)//500**2)
    threshold=(target**2*500**2+1983**2*energy-1)//(1983**2*energy)
    return {'endpoint_energy16':energy,'rho0_rational_upper':str(rational),
            'taylor_rational_upper':str(rho_upper),'non_dyadic_half_upper':improved,
            'necessary_half_energy_for_48410':threshold,'target':target}


def padd(a,b):
    return [(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))]


def pmul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b): c[i+j]+=x*y
    return c


def pvarnum(a):
    d=[i*x for i,x in enumerate(a)]; dd=[i*x for i,x in enumerate(d)]
    return padd(pmul(dd,a),[-x for x in pmul(d,d)])


def peval(a,x):
    out=0
    for v in reversed(a): out=out*x+v
    return out


def tree_checks():
    representatives={'()':[[]]}; checked=0
    for n in range(1,11):
        for g in representatives.values():
            coeff=[0]*(n+1)
            edges=[(v,w) for v in range(n) for w in g[v] if v<w]
            for mask in range(1<<n):
                if not any(mask>>a&1 and mask>>b&1 for a,b in edges): coeff[mask.bit_count()]+=1
            if n>=3:
                sigma=sum(comb(len(a)-1,2) for a in g if len(a)>=3)
                c3=comb(n,3)-(n-1)*(n-2)+sum(comb(len(a),2) for a in g)
                assert coeff[3]==c3
                assert sigma==sum(comb(len(a),2) for a in g)-(n-2)
                assert (sigma==0)==(max(map(len,g))<=2)
            checked+=1
        nxt={}
        for g in representatives.values():
            for v in range(n):
                h=[list(a) for a in g]+[[v]]; h[v].append(n)
                nxt.setdefault(tr.canonical(h),h)
        representatives=nxt
    p5=[1,5,6,1]; s5=[1,5,6,4,1]
    cross=padd(pmul(pvarnum(s5),pmul(p5,p5)),[-x for x in pmul(pvarnum(p5),pmul(s5,s5))])
    while cross and cross[-1]==0: cross.pop()
    order=next(i for i,x in enumerate(cross) if x)
    reduced=cross[order:]
    signs=[1 if x>0 else -1 for x in reduced if x]
    changes=sum(a!=b for a,b in zip(signs,signs[1:]))
    bracket=None
    for k in range(1,100000):
        if peval(reduced,F(k,1000))<0:
            bracket=[str(F(k-1,1000)),str(F(k,1000))]; break
    assert bracket is not None and peval(reduced,F(bracket[0]))>0
    tm=[]
    for m in range(1,31):
        g=[[] for _ in range(5*m+1)]
        for j in range(m):
            v=1+5*j
            for a,b in [(0,v),(v,v+1),(v+1,v+2),(v,v+3),(v+3,v+4)]: g[a].append(b);g[b].append(a)
        actual=tr.variance(tr.moments(g)); p=F(9**m,13**m+9**m)
        formula=(1-p)*F(94*m,169)+p*F(4*m,9)+p*(1-p)*(F(8*m,39)-1)**2
        assert actual==formula and actual>tr.variance(tr.moments(tr.path(5*m+1)))
        if m==1: tm1gap=actual-tr.variance(tr.moments(tr.path(6)))
        if m==2: tm2gap=actual-tr.variance(tr.moments(tr.path(11)))
        tm.append(str(actual))
    return {'small_activity_coefficient_trees_checked':checked,'star5_minus_path5_numerator_order':order,
            'reduced_polynomial_low_to_high':reduced,'positive_root_sign_changes':changes,
            'root_bracket':bracket,'branch_module_family_m_checked':[1,30],
            'm1_variance':tm[0],'m1_gap':str(tm1gap),
            'm2_variance':tm[1],'m2_gap':str(tm2gap)}


if __name__=='__main__':
    started=time.monotonic()
    report={}
    for name,run in [('sieve',sieve_checks),('square',square_checks),('records',record_checks),('dyadic',dyadic_checks),('tree',tree_checks)]:
        report[name]=run();print(name+': PASS',flush=True)
    report.update(status='PASS',seconds=round(time.monotonic()-started,3))
    (HERE/'extensions_v2_verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':'PASS','seconds':report['seconds'],
                     'sieve_cases':report['sieve']['triples'],
                     'rotation_depths':report['square']['minimum_rotation_depth_histogram'],
                     'spectral_upper':report['dyadic']['non_dyadic_half_upper'],
                     'tree_root_bracket':report['tree']['root_bracket']},ensure_ascii=False))
