"""Standard-library small-tree enumeration and exact variance checks."""
from collections import Counter
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

HERE = Path(__file__).resolve().parent


def canonical(g):
    def rooted(v, parent):
        return '('+''.join(sorted(rooted(w, v) for w in g[v] if w != parent))+')'
    return min(rooted(v, -1) for v in range(len(g)))


def multiply(a, b):
    z, m, q = a
    y, k, r = b
    return z*y, m*y+z*k, q*y+2*m*k+z*r


def moments(g):
    def rec(v, parent):
        off, on = (1,0,0), (1,1,1)
        for w in g[v]:
            if w == parent:
                continue
            a, b = rec(w, v)
            off = multiply(off, tuple(x+y for x, y in zip(a, b)))
            on = multiply(on, a)
        return off, on
    return tuple(x+y for x, y in zip(*rec(0, -1)))


def variance(t):
    z, m, q = t
    return F(q*z-m*m, z*z)


def subset_moments(g):
    edges = [(v, w) for v in range(len(g)) for w in g[v] if v < w]
    out = [0,0,0]
    for mask in range(1 << len(g)):
        if any((mask >> v)&1 and (mask >> w)&1 for v, w in edges):
            continue
        size = mask.bit_count()
        out[0] += 1
        out[1] += size
        out[2] += size*size
    return tuple(out)


def path(n):
    return [[w for w in (v-1, v+1) if 0 <= w < n] for v in range(n)]


def star(n):
    return [list(range(1, n))]+[[0] for _ in range(n-1)]


def weighted_variance(coefficients, activity):
    z = sum(a*activity**k for k, a in enumerate(coefficients))
    m = sum(k*a*activity**k for k, a in enumerate(coefficients))
    q = sum(k*k*a*activity**k for k, a in enumerate(coefficients))
    return F(q*z-m*m, z*z)


def main():
    representatives = {'()': [[]]}
    rows = []
    expected_counts = [1,1,1,2,3,6,11,23,47,106]
    for n in range(1, 11):
        assert len(representatives) == expected_counts[n-1]
        baseline = variance(moments(path(n)))
        equal = 0
        for g in representatives.values():
            t = moments(g)
            assert t == subset_moments(g)
            actual = variance(t)
            assert actual >= baseline
            equal += actual == baseline
            if n >= 3:
                pendant = Counter(g[v][0] for v in range(n) if len(g[v]) == 1)
                lower = sum(F(k*2**k, 4*(1+2**k)) for k in pendant.values())
                assert actual >= lower
        assert equal == 1
        rows.append({'n': n, 'nonisomorphic_trees': len(representatives),
                     'path_variance': str(baseline), 'equality_classes': equal})
        next_level = {}
        for g in representatives.values():
            for v in range(n):
                h = [list(a) for a in g]+[[v]]
                h[v].append(n)
                next_level.setdefault(canonical(h), h)
        representatives = next_level
    for n in range(4, 201):
        assert variance(moments(star(n))) > variance(moments(path(n)))
    p5 = [1,5,6,1]
    s5 = [1,5,6,4,1]
    weighted = {str(x): {'path5': str(weighted_variance(p5, x)),
                        'star5': str(weighted_variance(s5, x))} for x in (1,100)}
    assert weighted_variance(s5,1) > weighted_variance(p5,1)
    assert weighted_variance(s5,100) < weighted_variance(p5,100)
    # The 21-vertex auxiliary-lemma counterexample, checked independently by DP.
    trap = [[] for _ in range(21)]
    for j in range(4):
        v = 1+5*j
        for a, b in [(0,v),(v,v+1),(v+1,v+2),(v,v+3),(v+3,v+4)]:
            trap[a].append(b)
            trap[b].append(a)
    t = moments(trap)
    assert t == (35122,217313,1419977)
    original = variance(t)
    leaves = [v for v in range(21) if len(trap[v]) == 1]
    move_gaps = Counter()
    for j in range(4):
        v = 1+5*j
        for arm_root, arm_leaf in [(v+1,v+2),(v+3,v+4)]:
            for target in leaves:
                if target == arm_leaf:
                    continue
                h = [list(a) for a in trap]
                h[v].remove(arm_root); h[arm_root].remove(v)
                h[target].append(arm_root); h[arm_root].append(target)
                gap = variance(moments(h))-original
                assert gap > 0
                move_gaps[str(gap)] += 1
    assert sum(move_gaps.values()) == 56
    report = {'status':'PASS','complete_tree_checks':rows,'total_nonisomorphic_trees':sum(r['nonisomorphic_trees'] for r in rows),
              'all_small_moments_checked_by_subsets':True,'stars_checked_n4_through_200':True,
              'weighted_extension_counterexample':weighted,
              'auxiliary_lemma_trap':{'vertices':21,'moments':t,'variance':str(original),
                                     'path_gap':str(original-variance(moments(path(21)))),
                                     'move_gap_multiplicities':dict(move_gaps)}}
    (HERE/'tree_verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))


if __name__ == '__main__':
    main()
