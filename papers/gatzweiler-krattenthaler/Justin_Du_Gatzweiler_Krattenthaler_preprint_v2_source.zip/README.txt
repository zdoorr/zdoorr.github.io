A candidate proof of the Gatzweiler-Krattenthaler positivity conjecture
Justin Du
Preprint, version 2 | 11 November 2026
Contact: fbphdu@gmail.com

CONTENTS

Justin_Du_Gatzweiler_Krattenthaler_preprint_v2.tex
    Editable LaTeX manuscript with its bibliography embedded.
Justin_Du_Gatzweiler_Krattenthaler_preprint_v2.pdf
    Compiled preprint.
build.ps1 / build.sh
    Three-pass PDF builds for Windows PowerShell or a POSIX shell.
REVIEW_NOTES.txt
    Version-2 changes and the scope of the renewed mathematical review.
verification/
    Original verification materials, rerun results, and the new review audit.
original_materials/
    The supplied Chinese proof draft and original verification archive,
    preserved byte for byte as historical inputs.
release_checks.json
    Build and review checks. All file/hash records refer to packaged paths.
SHA256SUMS.txt
    Checksums for every other file in this package.
validate_package.py
    Self-contained path/hash validation using Python's standard library.

CHANGES IN VERSION 2

Lemma 5.1 derives g not dividing c and g > 1 from the two-multiple count,
and its unnecessary overall gcd normalization has been removed. Other
minor clarifications concern the remaining two-multiple case, a ceiling/
floor bound, the role of hypotheses, and the use of separate symbols for
lifts and coset counts. PDF command examples now retain literal double
hyphens. External layout-reference metadata has been removed from the
release checklist. See REVIEW_NOTES.txt for the section-by-section review.

BUILD

Use pdfLaTeX with these standard packages:
fontenc, inputenc, lmodern, geometry, amsmath, amssymb, amsthm, mathtools,
booktabs, tabularx, array, enumitem, fancyhdr, microtype, xurl, hyperref.
No shell escape, BibTeX run, external figures, or external fonts are needed.

Windows:
    powershell -ExecutionPolicy Bypass -File .\build.ps1
Linux or macOS:
    sh build.sh

Recompilation can change PDF timestamps and file hashes.

PACKAGE VALIDATION

From an extracted copy:
    python validate_package.py

This checks that each named payload exists, matches its hash and length,
and that the manifests cover the distributed files without dangling paths.

REPRODUCING THE AUDITS

Python 3.10 or newer and the standard library are sufficient.
From verification/, run each command as one line:

python verify_mixed_completion.py --k-max 16 --random-cases 6000 --seed 202611103 --out rerun/audit_main_rerun.json
python audit_local_mixed.py --cases 12000 --seed 202611102 --out rerun/audit_local_rerun.json
python review_v2/verify_three_generator_lemma.py --max-b 24 --max-width 7 --extra-length 2 --out review_v2/three_generator_audit.json

Audit elapsed times vary by machine. The original deterministic main/local
results match except for timing. The new audit checks witnesses without
normalizing overall gcds; exact scope and branch counts are in its JSON.
Finite computations are supplementary error checks and are not premises
of the infinite-parameter proof.

REVIEW STATUS

This remains an AI-assisted candidate proof, with the two external
mathematical inputs cited in Section 2. External human peer review and
proof-assistant formalization are not supplied. No priority claim is made.
