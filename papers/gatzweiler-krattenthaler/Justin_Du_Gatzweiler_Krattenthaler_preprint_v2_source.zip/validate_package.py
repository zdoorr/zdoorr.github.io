#!/usr/bin/env python3
"""Check every distributed payload against the package's self-contained manifests."""
from pathlib import Path, PurePosixPath
from zipfile import ZipFile
import hashlib
import json

root = Path(__file__).resolve().parent


def digest(data):
    return hashlib.sha256(data).hexdigest()


def checked_path(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and ".." not in path.parts, name
    target = root.joinpath(*path.parts)
    assert target.is_file(), ("Missing packaged file", name)
    return target


manifest = {}
for line in (root / "SHA256SUMS.txt").read_text(encoding="ascii").splitlines():
    value, name = line.split("  ", 1)
    assert name not in manifest
    manifest[name] = value
    assert digest(checked_path(name).read_bytes()) == value, name

actual = {
    p.relative_to(root).as_posix()
    for p in root.rglob("*")
    if p.is_file() and "__pycache__" not in p.parts and "build" not in p.relative_to(root).parts
}
assert set(manifest) == actual - {"SHA256SUMS.txt"}
checks = json.loads((root / "release_checks.json").read_text(encoding="utf-8"))
payloads = checks["package_files"]
assert set(payloads) == actual - {"SHA256SUMS.txt", "release_checks.json"}
for name, record in payloads.items():
    data = checked_path(name).read_bytes()
    assert len(data) == record["bytes"] and digest(data) == record["sha256"], name
assert checks["paper"]["version"] == "2"
for name in [checks["paper"]["pdf"], checks["paper"]["source"]]:
    checked_path(name)
for audit in checks["audits"]:
    checked_path(audit["script"])
    result = json.loads(checked_path(audit["result"]).read_text(encoding="utf-8"))
    assert result["status"] == audit["status"]
    assert result["statistics"] == audit["statistics"]

with ZipFile(checked_path("original_materials/mixed_sumset_completion_verified.zip")) as archive:
    old = json.loads(archive.read("SHA256.json"))
    for name, value in old.items():
        assert digest(archive.read(name)) == value
        assert digest(checked_path("verification/" + name).read_bytes()) == value
print(json.dumps({
    "status": "all packaged paths and hashes verified",
    "manifest_files": len(manifest),
    "release_check_payloads": len(payloads),
    "original_internal_hashes": len(old),
}))
