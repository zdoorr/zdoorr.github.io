#!/usr/bin/env python3
"""Finite witness checks for the general interval lemma, without gcd reduction."""
from pathlib import Path
from itertools import combinations
from collections import Counter
import argparse
import json
import math
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from verify_mixed_completion import oracle, basic_dp


def direct(I, N, U):
    return {
        b: set(range(((N + b - 1) // b) * b, U + 1, b))
        for b in I
    }


def collision_witness(a, b, c, x, N, U, B, stats):
    g = math.gcd(a, b)
    L = a * b // g
    F = L - a - b
    multiples = list(range(((N + g - 1) // g) * g, U + 1, g))
    assert len(multiples) >= 2 and x >= L
    if len(multiples) >= 3:
        i = multiples.index(x)
        start = min(max(i - 2, 0), len(multiples) - 3)
        result = set(multiples[start:start + 3])
        assert min(result) >= x - 2 * g > F
        stats["three_g_multiples_certificates"] += 1
        return result
    assert len([b0 for b0 in B if b0 % g == 0]) == 2
    assert a % g == b % g == 0 and c % g != 0 and g > 1
    assert b == a + g and c < b + g
    assert U - N + 1 >= len(B) >= g + 1
    assert N > x - 2 * g >= L - 2 * g
    assert min(multiples) >= x - g > F
    if math.gcd(math.gcd(a, b), c) > 1:
        stats["nonprimitive_two_multiple_certificates"] += 1
    v = a // g
    result = set(multiples)
    choices = [y for y in range(N, U + 1) if (y - c) % g == 0]
    assert choices
    if v == 1:
        assert choices[0] > c
        result.add(choices[0])
        stats["v_equals_one_certificates"] += 1
    elif v >= 3:
        assert F + c < L - (v - 1) * g <= L - 2 * g < N
        result.add(choices[0])
        stats["v_at_least_three_certificates"] += 1
    elif c <= 3 * g:
        assert F == g and F + c <= 4 * g < N
        result.add(choices[0])
        stats["v_equals_two_lower_c_certificates"] += 1
    else:
        s = c - 3 * g
        j = x // (6 * g)
        assert 1 <= s < g and j >= 1 and x == 6 * j * g
        y, z = x - g + s, x + s
        assert y == c + 2 * g * (3 * j - 2)
        assert z == c + 3 * g * (2 * j - 1)
        assert y < x < z and z - y == g
        in_interval = [w for w in [y, z] if N <= w <= U]
        assert in_interval
        result.add(in_interval[0])
        stats["v_equals_two_upper_c_certificates"] += 1
    assert len(result) == 3
    return result


def check_subset(I, N, U, B, stats):
    hits = direct(I, N, U)
    assert all(hits.values())
    union = set().union(*hits.values())
    truth = oracle(I, N, U)
    witnesses = []
    if len(union) >= len(I):
        witnesses.append(union)
        stats["direct_multiple_subsets"] += 1
    elif len(I) == 2:
        a, b = I
        x = next(iter(union))
        g = math.gcd(a, b)
        L = a * b // g
        choices = [y for y in [x - g, x + g] if N <= y <= U]
        assert choices and choices[0] >= L - g > L - a - b
        witnesses.append({x, choices[0]})
        stats["pair_collision_subsets"] += 1
    else:
        assert len(I) == 3
        for a, b in combinations(I, 2):
            c = next(c for c in I if c not in [a, b])
            for x in sorted(hits[a] & hits[b]):
                witnesses.append(collision_witness(a, b, c, x, N, U, B, stats))
        assert witnesses
        stats["triple_collision_subsets"] += 1
    assert len(truth) >= len(I)
    assert all(len(w) >= len(I) and w <= truth for w in witnesses)
    if stats["subsets_checked"] % 200 == 0:
        assert truth == basic_dp(I, N, U)
        stats["two_algorithm_checks"] += 1
    stats["witnesses_checked"] += len(witnesses)
    stats["subsets_checked"] += 1
    if len(I) == 3 and math.gcd(*I) > 1:
        stats["nonprimitive_triples_checked"] += 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-b", type=int, default=24)
    parser.add_argument("--max-width", type=int, default=7)
    parser.add_argument("--extra-length", type=int, default=2)
    parser.add_argument("--out", type=Path, default=Path("three_generator_audit.json"))
    args = parser.parse_args()
    stats = Counter()
    start = time.monotonic()
    for k in range(3, args.max_b + 1):
        for width in range(3, min(k, args.max_width) + 1):
            B = tuple(range(k - width + 1, k + 1))
            counts_B = [sum(b % s == 0 for b in B) for s in range(1, k + 1)]
            subsets = [I for r in [1, 2, 3] for I in combinations(B, r)]
            for length in range(width, width + args.extra_length + 1):
                for N in range(k + 1, k * k + 1):
                    U = N + length - 1
                    stats["interval_pairs_scanned"] += 1
                    if any(U // s - (N - 1) // s < counts_B[s - 1] for s in range(1, k + 1)):
                        continue
                    stats["admissible_interval_pairs"] += 1
                    for I in subsets:
                        check_subset(I, N, U, B, stats)
    assert all(stats[name] > 0 for name in [
        "three_g_multiples_certificates", "nonprimitive_two_multiple_certificates",
        "v_equals_one_certificates", "v_at_least_three_certificates",
        "v_equals_two_lower_c_certificates", "v_equals_two_upper_c_certificates",
    ])
    result = {
        "status": "all exact witness checks passed",
        "scope": {
            "max_B_range": [3, args.max_b],
            "B_length_range": [3, args.max_width],
            "A_length": "B_length through B_length + extra_length",
            "extra_length": args.extra_length,
            "A_left_endpoint": "max(B)+1 through max(B)^2, inclusive",
            "subset_sizes": [1, 2, 3],
            "condition": "all divisibility counts and separated positive intervals",
            "overall_gcd_normalization": False,
        },
        "statistics": dict(stats),
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "limitation": "Finite error checks; the infinite-parameter proof is in the manuscript.",
    }
    args.out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
