#!/usr/bin/env python3
"""Independent exact audits for a proposed full-range semigroup proof.

Finite audits do not prove an infinite theorem.  All assertions in this file
are integer checks of the lemmas stated in the accompanying manuscript.
Only Python's standard library is required.
"""
from __future__ import annotations
import argparse
from collections import Counter
from itertools import combinations
import json, math, random, time
from pathlib import Path


def polynomial(k:int,l:int,n:int)->bool:
    N,U=n-k+1,n-l
    return all(U//s-(N-1)//s>=k//s-l//s for s in range(k,1,-1))


def oracle(I:tuple[int,...],N:int,U:int)->set[int]:
    # Unbounded coin DP by doubling the available number of each coin.
    mask=(1<<(U+1))-1
    bits=1
    for b in I:
        step=b
        while step<=U:
            bits=(bits | (bits<<step)) & mask
            step*=2
    return {y for y in range(N,U+1) if (bits>>y)&1}


def basic_dp(I:tuple[int,...],N:int,U:int)->set[int]:
    # A second, independent dynamic programming formulation.
    good=bytearray(U+1); good[0]=1
    for y in range(1,U+1):
        good[y]=any(y>=b and good[y-b] for b in I)
    return {y for y in range(N,U+1) if good[y]}


def direct_hits(I:tuple[int,...],N:int,U:int)->dict[int,list[int]]:
    ans={}
    for b in I:
        for x in range(((N+b-1)//b)*b,U+1,b):
            ans.setdefault(x,[]).append(b)
    return ans


def stabilizer_step(Q:set[int],m:int)->int:
    for g in range(1,m+1):
        if m%g==0 and {(q+g)%m for q in Q}==Q:
            return g
    raise AssertionError('No stabilizer, even the trivial one?')


def mixed_certificate(I:tuple[int,...],k:int,l:int,n:int,stats:Counter,
                      audit_period:bool=False)->set[int]:
    d,N,U=k-l,n-k+1,n-l
    L=tuple(b for b in I if b<=d)
    assert L
    m=max(L); M=max(I)
    assert l<m<=d and N>M
    S={b%m for b in I}; T={c%m for c in L}
    Q={(b+c)%m for b in S for c in T}
    hits={y for y in range(N,U+1) if y%m in Q}
    assert len(hits)>=len(I),('mixed count',k,l,n,I,m,hits)
    # Independently construct an actual nonnegative representation.
    repsS={0:0}; repsT={0:0}
    for b in I:
        repsS.setdefault(b%m,b)
    for c in L:
        repsT.setdefault(c%m,c)
    repsQ={}
    for s,b in repsS.items():
        for t,c in repsT.items():
            repsQ.setdefault((s+t)%m,(b,c))
    for y in hits:
        b,c=repsQ[y%m]; z=b+c
        assert z<=M+m and y>=z and (y-z)%m==0
        assert b==0 or b in I
        assert c==0 or c in I
    if audit_period:
        g=stabilizer_step(Q,m);h=m//g
        z=len({b%g for b in I});w=len({c%g for c in L});v=len({q%g for q in Q})
        assert v>=z+w-1
        alpha=l//g;beta=(l+g-1)//g;CB=k//g-l//g
        upper=CB+(w-1)*(h-alpha)+(z-1)*beta
        lower=CB+(v-1)*(d//g)
        assert 0<=alpha<=beta<=h
        assert len(I)<=upper<=lower<=len(hits)
        assert (z+w-2)*h-((w-1)*(h-alpha)+(z-1)*beta)==(z-1)*(h-beta)+(w-1)*alpha
        stats['periodic_mixed' if h>1 else 'aperiodic_mixed']+=1
        if len(S)<len(I):stats['image_has_collisions']+=1
        if len(I)>len(L):stats['genuinely_mixed_subsets']+=1
    stats['mixed_certificates']+=1
    return hits


def tail_certificate(I:tuple[int,...],k:int,l:int,n:int,stats:Counter)->set[int]:
    d,N,U=k-l,n-k+1,n-l
    assert l>=1 and k>=3*l-1 and min(I)>d
    D=direct_hits(I,N,U)
    assert all(any(b in v for v in D.values()) for b in I)
    if len(D)>=len(I):
        stats['tail_direct']+=1
        return set(D)
    x,J=next((x,J) for x,J in D.items() if len(J)>=2)
    a,b=sorted(J[:2]);g=math.gcd(a,b)
    u,v=a//g,b//g;K=k//g
    F=a*b//g-a-b
    assert g<=l-1 and d>=l+g and u+v>=K+2
    hits=set()
    for cmod in {c%g for c in I}:
        members=[c for c in I if c%g==cmod];c=min(members);r=len(members)
        total=(U-c)//g-(N-1-c)//g
        tail=(U-c)//g-F//g
        actual={y for y in range(N,U+1) if y%g==cmod and y-c>F}
        assert len(actual)==max(0,min(total,tail))
        assert total>=r and tail>=r and len(actual)>=r
        hits.update(actual)
    assert len(hits)>=len(I)
    stats['tail_collision']+=1
    return hits


def small_l_certificate(I:tuple[int,...],k:int,l:int,n:int,stats:Counter,
                        audit_period:bool=False)->set[int]:
    t=n//k;d,N,U=k-l,n-k+1,n-l
    assert l<=3*(t-1)
    r=len(I);m=max(I)
    if r<=3:
        H=oracle(I,N,U)
        assert len(H)>=r,('at most three generators',k,l,n,I,H)
        stats['small_l_at_most_three']+=1
        return H
    if m<=d:
        H={b+((N-b+m-1)//m)*m for b in I}
        assert len(H)==r and min(H)>=N and max(H)<=U
        return H
    S={b%m for b in I};Q={0}
    for _ in range(t):Q={(a+b)%m for a in Q for b in S}
    H={y for y in range(N,U+1) if y%m in Q}
    assert len(H)>=r,('small l',k,l,n,I,H)
    if audit_period:
        g=stabilizer_step(Q,m);h=m//g
        z=len({a%g for a in S});w=len({a%g for a in Q});v=h-l//g
        assert w>=t*z-(t-1) and v>=1 and r<=z*v
        if v>=2:
            assert v+(w-1)*(v-1)>=r
        elif d>=g:
            assert w>=r
        else:
            assert z==r and (t-1)*(r-1)>=m-d
            assert t*r-(t-1)-(g-d)>=r
    stats['small_l_sumset']+=1
    return H


def boundary_certificate(I:tuple[int,...],k:int,l:int,n:int,stats:Counter)->set[int]:
    d,N,U=k-l,n-k+1,n-l
    assert n<3*k and l>=3 and min(I)>d
    if k==3*l-3:
        g=l-1
        assert n==7*l-6 and (N,U)==(4*g+2,6*g)
        if 3*g in I:
            H={c+3*g for c in I}
        else:
            H={6*g if c==2*g else 2*c for c in I}
        stats['boundary_k_3l_minus_3']+=1
    elif k==3*l-2:
        assert n==7*l-3 and (N,U)==(4*l,6*l-3)
        H={3*c if c==2*l-1 else 2*c for c in I}
        stats['boundary_k_3l_minus_2']+=1
    else:
        raise AssertionError(('not a boundary',k,l,n,I))
    assert len(H)==len(I) and all(N<=y<=U for y in H)
    return H


def certificate(I:tuple[int,...],k:int,l:int,n:int,stats:Counter,
                audit_period:bool=False)->set[int]:
    d=k-l;t=n//k
    if len(I)==1:
        hits=set(direct_hits(I,n-k+1,n-l))
        assert hits
        stats["singleton_certificates"]+=1
        return hits
    if any(b<=d for b in I):
        return mixed_certificate(I,k,l,n,stats,audit_period)
    if k>=3*l-1:
        return tail_certificate(I,k,l,n,stats)
    if l<=3*(t-1):
        return small_l_certificate(I,k,l,n,stats,audit_period)
    assert t==2,('algebraic reduction',k,l,n)
    assert k in (3*l-3,3*l-2),('layer inequality',k,l,n)
    return boundary_certificate(I,k,l,n,stats)


def coefficient_identity(k:int,l:int,n:int)->int:
    d,N,U=k-l,n-k+1,n-l;degree=d*(n-k-l)
    C=[0]*(degree+1);C[0]=1
    for b in range(l+1,k+1):
        for j in range(b,degree+1):C[j]+=C[j-b]
    for a in range(N,U+1):
        for j in range(degree,a-1,-1):C[j]-=C[j-a]
    assert min(C)>=0,('negative coefficient',k,l,n)
    left=C[:]
    for b in range(l+1,k+1):
        old=left;left=old+[0]*b
        for j,c in enumerate(old):left[j+b]-=c
    right=[1]
    for a in range(N,U+1):
        old=right;right=old+[0]*a
        for j,c in enumerate(old):right[j+a]-=c
    assert left==right,('full identity failed',k,l,n)
    return len(C)


def audit(I:tuple[int,...],k:int,l:int,n:int,stats:Counter,
          audit_period:bool=False,double_oracle:bool=False)->None:
    H=certificate(I,k,l,n,stats,audit_period)
    truth=oracle(I,n-k+1,n-l)
    assert len(H)>=len(I) and H<=truth,('certificate',k,l,n,I,H,truth)
    if double_oracle:
        assert truth==basic_dp(I,n-k+1,n-l)
        stats['two_independent_oracles']+=1
    stats['subsets_verified']+=1


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--k-max',type=int,default=14)
    ap.add_argument('--random-cases',type=int,default=2000)
    ap.add_argument('--seed',type=int,default=202611101)
    ap.add_argument('--out',type=Path,default=Path('mixed_audit.json'))
    args=ap.parse_args();stats=Counter();start=time.monotonic();cases=[]
    for k in range(2,args.k_max+1):
        for l in range(1,k):
            for n in range(2*k,7*k+1):
                stats['parameters_scanned']+=1
                if not polynomial(k,l,n):continue
                stats['polynomial_parameters']+=1;cases.append((k,l,n))
                if k-l>=2:
                    t=n//k
                    assert k>=(t+1)*(l-t+1)
                    assert t*k+l<=n<=(t+1)*k-t*l+t*t-1
                B=range(l+1,k+1)
                for r in range(1,k-l+1):
                    for I in combinations(B,r):
                        audit(I,k,l,n,stats,audit_period=True,
                              double_oracle=stats['subsets_verified']%2500==0)
    rng=random.Random(args.seed);saved=[];attempts=0
    while len(saved)<args.random_cases:
        attempts+=1
        k=rng.randint(15,600);t=rng.choices([2,3,4,5,6,8,10,15],[12,2,1,1,1,1,1,1])[0]
        l=rng.randint(1,min(k-2,t-1+k//(t+1)))
        lo=t*k+l;hi=min((t+1)*k-1,(t+1)*k-t*l+t*t-1)
        if lo>hi:continue
        n=rng.randint(lo,hi)
        if not polynomial(k,l,n):continue
        saved.append((k,l,n));stats['random_polynomial_parameters']+=1
        B=tuple(range(l+1,k+1));d=k-l
        for _ in range(12):
            r=rng.randint(1,min(50,len(B)))
            I=tuple(sorted(rng.sample(B,r)))
            audit(I,k,l,n,stats,audit_period=True,
                  double_oracle=stats['subsets_verified']%2500==0)
        Tail=tuple(range(max(l+1,d+1),k+1))
        if Tail:
            I=tuple(sorted(rng.sample(Tail,rng.randint(1,len(Tail)))))
            audit(I,k,l,n,stats,audit_period=True)
        # Deliberately create mixed sets with very few low generators.
        Low=tuple(range(l+1,d+1))
        if Low and Tail:
            I=tuple(sorted(rng.sample(Low,min(len(Low),rng.randint(1,3)))+
                           rng.sample(Tail,rng.randint(1,len(Tail)))))
            audit(I,k,l,n,stats,audit_period=True)
    # Infinite boundary families: audit regardless of full polynomiality.
    # The boundary injections use only the indicated exact parameters.
    for l in range(3,301):
        for k,n in [(3*l-3,7*l-6),(3*l-2,7*l-3)]:
            Tail=tuple(range(k-l+1,k+1))
            for _ in range(8):
                I=tuple(sorted(rng.sample(Tail,rng.randint(1,len(Tail)))))
                H=boundary_certificate(I,k,l,n,stats)
                assert H<=oracle(I,n-k+1,n-l)
                stats['boundary_injections_without_polynomial_assumption']+=1
    identities=set(cases[::max(1,len(cases)//35)])
    internal=[c for c in saved if c[1]>=3 and c[0]-c[1]>=4 and c[2]<3*c[0] and c[0]<=100]
    identities.update(internal[:20])
    identities.update((3*l-3,l,7*l-6) for l in range(3,20) if polynomial(3*l-3,l,7*l-6))
    for k,l,n in sorted(identities):
        stats['coefficients_checked']+=coefficient_identity(k,l,n)
        stats['full_polynomial_identities']+=1
    out={'status':'all exact checks passed','seed':args.seed,'k_max':args.k_max,
         'statistics':dict(stats),'random_parameter_attempts':attempts,
         'full_identity_parameters':sorted(identities),
         'elapsed_seconds':round(time.monotonic()-start,3),
         'scope':'Finite audits, not the proof of the infinite theorem.'}
    args.out.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
