#!/usr/bin/env python3
"""Audit the mixed-sumset lemma with much weaker, local hypotheses.
Full polynomiality is deliberately not assumed.
"""
from collections import Counter
import random,json,time,argparse
from pathlib import Path
from verify_mixed_completion import stabilizer_step,oracle,basic_dp

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out',type=Path,default=Path('local_mixed_audit.json'))
    ap.add_argument('--cases',type=int,default=12000)
    ap.add_argument('--seed',type=int,default=202611102)
    args=ap.parse_args()
    rng=random.Random(args.seed);stats=Counter();start=time.monotonic()
    examples=[]
    for _ in range(args.cases):
        k=rng.randint(5,2500); l=rng.randint(0,(k-1)//2)
        d=k-l;m=rng.randint(l+1,d)
        L={m}; L.update(rng.sample(range(l+1,m),min(m-l-1,rng.randint(0,12))))
        High=set(rng.sample(range(d+1,k+1),min(l,rng.randint(0,16))))
        I=tuple(sorted(L|High)); N=rng.randint(k+1,12*k); U=N+d-1
        S={x%m for x in I};T={x%m for x in L};Q={(x+y)%m for x in S for y in T}
        g=stabilizer_step(Q,m);h=m//g
        CA=U//g-(N-1)//g;CB=k//g-l//g
        stats['local_cases_generated']+=1
        if CA<CB:
            stats['local_hypothesis_not_met']+=1;continue
        z=len({b%g for b in I});w=len({c%g for c in L});v=len({c%g for c in Q})
        a=l//g;b=(l+g-1)//g
        assert v>=z+w-1
        upper=CB+(w-1)*(h-a)+(z-1)*b
        lower=CA+(v-1)*(d//g)
        hits={y for y in range(N,U+1) if y%m in Q}
        assert len(I)<=upper<=lower<=len(hits)
        RS={0:0};RT={0:0}
        for x in I:RS.setdefault(x%m,x)
        for x in L:RT.setdefault(x%m,x)
        witnesses={}
        for s,x in RS.items():
            for t,y in RT.items():witnesses.setdefault((s+t)%m,(x,y))
        for y in hits:
            a,b=witnesses[y%m]
            assert y>=a+b and (y-a-b)%m==0
        if stats['local_cases_passed']%40==0:
            assert hits<=oracle(I,N,U)
            stats['independent_oracle_checks']+=1
        stats['periodic' if h>1 else 'aperiodic']+=1
        stats['local_cases_passed']+=1
    out={'status':'passed','seed':args.seed,'statistics':dict(stats),
         'elapsed_seconds':round(time.monotonic()-start,3),
         'note':'Only C_A(g)>=C_B(g) for the actual stabilizer modulus g was imposed; full polynomiality was not imposed.'}
    args.out.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
