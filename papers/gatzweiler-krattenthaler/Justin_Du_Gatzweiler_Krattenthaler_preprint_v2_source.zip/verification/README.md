# 混合和集证明稿与精确核验

这是本轮推导的完整候选证明稿，尚未经独立审阅；不声称已经公开发表或获得同行认可。

## 文件

- `complete_proof.md`：自足的中文证明稿；除两个注明的外部定理外，所有辅助引理均重证。
- `verify_mixed_completion.py`：全参数分支、构造命中点、周期计数、独立半群算法及完整多项式恒等式核验。
- `audit_main.json`：扩大范围、第二随机种子的实际运行结果。
- `audit_first_pass.json`：第一轮运行结果。
- `audit_local_mixed.py`：不假设完整多项式性的混合和集引理压力测试。
- `audit_local.json`：对应实际结果；不满足局部假设的样本被明确计为未纳入，而非通过。
- `rejected_double_sum_claim.json`：旧的二重和集强命题的确切反例。
- `SHA256.json`：其他文件的校验值。

## 复现

只需要 Python 3.10 或更新版本和标准库，无网络、无第三方包。

```bash
python verify_mixed_completion.py --k-max 16 --random-cases 6000 --seed 202611103 --out audit_main_rerun.json
python audit_local_mixed.py --cases 12000 --seed 202611102 --out audit_local_rerun.json
```

统计和参数是确定性的；耗时字段随设备而变。

主核验穷尽 2≤k≤16、1≤l<k、2k≤n≤7k 的所有参数，并检查每个多项式实例的全部非空分母子集；另用固定种子在 k≤600 的 6000 个多项式实例中抽取子集。独立检查两条边界的单射时不假设多项式性。对选定实例，乘回分母时没有截断。

## 证明与计算的边界

无限命题由 `complete_proof.md` 中的符号论证承担，有限检查仅用于找错。没有用“检查到了某个 k”代替无限参数证明。

外部审阅最值得检查的两处：第 3 节混合和集的陪集容量上、下界，以及第 9 节的参数分类。第 4 节已将曾经有争议的左端截断明确写成两个尾段容量的最小值。
