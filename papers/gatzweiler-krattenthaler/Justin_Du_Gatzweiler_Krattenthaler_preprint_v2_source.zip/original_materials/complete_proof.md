# Gatzweiler–Krattenthaler 非负性猜想：混合和集证明稿

日期：2026-11-10。性质：本次对话中推导的候选完整证明，尚未经独立同行审阅，不声称文献首证。

本文不以先前聊天中的二次、三分之四次或线性阈值为黑箱；所需辅助引理全部在下文重证。有限计算只用于查错，不承担任何无限参数分支。

## 1. 主命题及仅有的两个外部输入

**主命题。** 对整数 \(0\le l<k\le n/2\)，若
\[
P_{n,k,l}(q)=\frac{{n\brack k}_q}{{n\brack l}_q}\in\mathbb Z[q],
\]
则 \(P_{n,k,l}(q)\in\mathbb Z_{\ge0}[q]\)。

定义
\[
d=k-l,\quad N=n-k+1,\quad U=n-l,\qquad
A=[N,U]\cap\mathbb Z,\quad B=[l+1,k]\cap\mathbb Z.
\]
有 \(|A|=|B|=d\) 和 \(N>k\)。消去阶乘后，
\[
P(q)=\frac{\prod_{a\in A}(1-q^a)}{\prod_{b\in B}(1-q^b)}.
\]
比较圆分因子即得
\[
C_A(s):=|A\cap s\mathbb Z|\ \ge\ C_B(s):=|B\cap s\mathbb Z|
\qquad(s\ge1).\tag{D}
\]
对 \(s\ge2\) 是 \(\Phi_s\) 的重数比较；对 \(s=1\) 是区间等长。

以下仅使用两个外部定理。

**外部输入 G。** Gatzweiler–Levicán-Santibáñez–Yoshida [1] 的 Propositions 3.3 和 3.6：如果对每个非空 \(I\subseteq B\)，都有
\[
|A\cap\langle I\rangle|\ge |I|,\tag{H}
\]
其中 \(\langle I\rangle\) 表示非负整数线性组合构成的加法半群，则 \(P(q)\) 有非负整数系数。这是其正则序列判据及 Hilbert 级数公式在两个等长无重复集合上的应用。

**外部输入 K。** Kneser 加法定理 [2]：对于有限阿贝尔群中的非空有限集合 \(S,T\)，令 \(H=\operatorname{Stab}(S+T)\)，则
\[
|S+T|\ge |S+H|+|T+H|-|H|.
\]
若 \(S,T,S+T\) 分别占据 \(z,w,v\) 个 \(H\) 陪集，则 \(v\ge z+w-1\)。对于 \(pS\) 的稳定子群也有
\[
|pS|\ge p|S+H|-(p-1)|H|.\tag{K}
\]
迭代式可在商群中逐次应用二集合定理：任一中间和集的稳定子群都包含于最终和集的稳定子群，故商群中的中间和集均无周期。

我们将对所有 \(I\) 证明 (H)。

## 2. 基本的两生成元表示公式

对不同正整数 \(a,b\)，令
\[
g=\gcd(a,b),\quad L=ab/g,\quad F=L-a-b.
\]
每个严格大于 \(F\) 的非负 \(g\) 的倍数，都属于 \(\langle a,b\rangle\)。

证明：约去 \(g\)，写 \(a=ug,b=vg\)，其中 \(\gcd(u,v)=1\)。若整数 \(w>uv-u-v\)，取 \(j\in\{0,\ldots,u-1\}\) 使 \(jv\equiv w\pmod u\)。则 \(w-jv>-u\)，且为 \(u\) 的倍数，故非负。因此 \(w\in\langle u,v\rangle\)。

## 3. 新的混合和集引理：所有含有较小生成元的子集

**引理 M。** 只要 \(I\subseteq B\) 非空且 \(I\cap[1,d]\ne\varnothing\)，就满足 (H)。这里只需 \(N>k\) 和 (D)，不需要 \(N>2k\)。

### 3.1 选取最大的小生成元

令
\[
L_0=I\cap[1,d],\qquad m=\max L_0,\qquad M=\max I.
\]
于是 \(l<m\le d\)，并且
\[
L_0\subseteq[l+1,m],\qquad I\setminus L_0\subseteq[d+1,k].\tag{3.1}
\]
第二个区间的长度恰为 \(l\)。注意选择的是“最大的、不超过 \(d\) 的生成元”；因此 \((m,d]\) 中没有 \(I\) 的元素。

在 \(\mathbb Z/m\mathbb Z\) 中定义
\[
S=I\bmod m,\qquad T=L_0\bmod m,\qquad Q=S+T.
\]
两个集合均包含零。

### 3.2 混合和集中的剩余类都能提升成非负表示

若 \(y\in A\) 且 \(y\bmod m\in Q\)，选择相应生成元代表，零剩余类允许选空和，得到可表示整数 \(z\)，使
\[
0\le z\le M+m,\qquad z\equiv y\pmod m.
\]
若 \(z>y\)，则
\[
z\ge y+m\ge N+m>M+m,
\]
矛盾。因此 \(y=z+jm\)，其中 \(j\ge0\)。由于 \(m\in I\)，有 \(y\in\langle I\rangle\)。

### 3.3 包含周期结构的完整容量计数

令 \(H=\operatorname{Stab}(Q)\)。存在 \(g\mid m\)，使
\[
H=\{0,g,\ldots,m-g\},\qquad h=|H|=m/g.
\]
设 \(S,T,Q\) 分别占据 \(z,w,v\) 个 \(H\) 陪集。这些陪集就是模 \(g\) 的剩余类。Kneser 给出
\[
v\ge z+w-1.\tag{3.2}
\]
令
\[
\alpha=\lfloor l/g\rfloor,\qquad \beta=\lceil l/g\rceil.
\]
由于 \(l<m\)，有 \(0\le\alpha\le\beta\le h\)。

分别用 (3.1) 中的两个整数区间估计生成元的数量：

* 零剩余类中，\(I\) 的元素总数至多为 \(C_B(g)\)。这里不把高、低两部分重复计算。
* \(L_0\) 每个非零剩余类至多有 \(h-\alpha\) 个元素，非零类最多 \(w-1\) 个。
* \(I\setminus L_0\) 每个非零剩余类至多有 \(\beta\) 个元素，非零类最多 \(z-1\) 个。

因此
\[
|I|\le C_B(g)+(w-1)(h-\alpha)+(z-1)\beta.\tag{3.3}
\]

另一方面，\(0\in Q\) 且 \(Q\) 为 \(H\)-周期集，所以整个零陪集 \(H\) 包含在 \(Q\) 中。其在 \(A\) 内的点数至少为 \(C_B(g)\)，这是 (D)。每个其他被 \(Q\) 占据的陪集在 \(A\) 内至少有
\[
\lfloor d/g\rfloor\ge m/g=h
\]
个点。因此可表示点的数量至少为
\[
C_B(g)+(v-1)h\ge C_B(g)+(z+w-2)h.\tag{3.4}
\]
最后，(3.4) 与 (3.3) 两个右侧之差为
\[
\boxed{(z-1)(h-\beta)+(w-1)\alpha\ge0.}\tag{3.5}
\]
于是 \(|A\cap\langle I\rangle|\ge|I|\)。引理 M 得证。

这个证明保留了原始生成元的重数容量，并没有假设 \(|S|=|I|\)，也没有假设稳定子群平凡。

## 4. 右端子集引理及左端截断的精确处理

**引理 R。** 设 \(l\ge1\)、\(k\ge3l-1\)，且
\[
I\subseteq[d+1,k].
\]
只要每个 \(b\in I\) 有一个倍数落在 \(A\) 中，就有 (H)。

直接倍数的并集若已有至少 \(|I|\) 个点，就完成了。否则存在不同的 \(a<b\in I\) 和共同倍数 \(x\in A\)。记
\[
g=\gcd(a,b),\quad a=ug,\quad b=vg,\quad J=\lfloor k/g\rfloor,
\]
\[
L=ab/g,
\qquad F=L-a-b.
\]
有 \(U\ge x\ge L\)。

因为 \(I\) 位于长度为 \(l\) 的右端区间，
\[
g\le b-a\le l-1,
\quad d=k-l\ge2l-1\ge l+g,
\]
故
\[
\lfloor d/g\rfloor\ge\lceil l/g\rceil.\tag{4.1}
\]
又因 \(a,b>d\ge k/2\)，两个不同整数 \(u<v\) 满足
\[
u+v\ge J+2.\tag{4.2}
\]

固定一个被 \(I\) 占据的模 \(g\) 剩余类，设其中有 \(r_c\) 个元素，最小者为 \(c\)。则
\[
r_c\le\lfloor(k-c)/g\rfloor+1.\tag{4.3}
\]
我们选择满足 \(y\equiv c\pmod g\) 及 \(y>F+c\) 的 \(A\) 元素。它们均属于 \(c+\langle a,b\rangle\subseteq\langle I\rangle\)。

为严谨处理左端，定义
\[
C_c=\left\lfloor\frac{U-c}{g}\right\rfloor-
\left\lfloor\frac{N-1-c}{g}\right\rfloor,
\quad
Q_c=\left\lfloor\frac{U-c}{g}\right\rfloor-\frac Fg.
\]
实际可选点数恰为
\[
\boxed{\max\{0,\min(C_c,Q_c)\}.}\tag{4.4}
\]
这两个数分别是同一剩余类内“整个区间”和“阈值以上尾段”的容量；两段具有相同右端。

由 (4.1)，\(C_c\ge\lceil l/g\rceil\ge r_c\)。另一方面，利用 \(U\ge L\)，
\[
\begin{aligned}
Q_c
&\ge u+v-\lceil c/g\rceil\\
&\ge J+2-\lceil c/g\rceil\\
&\ge\lfloor(k-c)/g\rfloor+1\ge r_c.
\end{aligned}\tag{4.5}
\]
其中倒数第二步是
\(\lceil c/g\rceil+\lfloor(k-c)/g\rfloor+1\le J+2\)。
因此 (4.4) 至少为 \(r_c\)。不同剩余类互不相交，求和即得 (H)。引理 R 得证。

这里没有把单个碰撞对的最大公因子误当成整个 \(I\) 的公因子；对任意其他 \(c\)，使用的是平移半群 \(c+\langle a,b\rangle\)。也不需要把不同碰撞组分别匹配。

**推论。** 如果 \(k\ge3l-1\)，则所有 \(n\ge2k\) 的多项式实例均有非负系数。对任意 \(I\)，包含不超过 \(d\) 的生成元时用 M，否则用 R。

## 5. 至多三个生成元的命中条件

本节允许更一般的两个整数区间 \(A,B\)：\(\min A>\max B\)、\(|A|\ge|B|\)，并满足 (D)。证明所有 \(1\le|I|\le3\) 均满足 (H)。

一个生成元直接用 (D)。两个生成元 \(a,b\) 若直接倍数已命中两个位置，就完成；否则取共同倍数 \(x\in A\)，令 \(g=\gcd(a,b)\)。由 (D)，\(A\) 至少含两个 \(g\) 的倍数，所以 \(x-g\) 或 \(x+g\) 中至少一个仍在 \(A\)。该点不小于
\[
x-g\ge ab/g-g>ab/g-a-b,
\]
故可表示。

对三个生成元，先约去整体公因子 \(h\)。\((A\cap h\mathbb Z)/h\) 与 \((B\cap h\mathbb Z)/h\) 仍为前后分离的整数区间；由 (D)，前者长度不少于后者，而且对每个模数 \(s\) 的新倍数计数是原来的模数 \(hs\) 计数。因此可假设整体互素。

若直接倍数不足三个位置，取碰撞对 \(a<b\) 及第三个生成元 \(c\)，令
\[
g=\gcd(a,b),\quad L=ab/g,\quad F=L-a-b,
\]
并取共同倍数 \(x\in A\)。

若 \(A\) 至少含三个 \(g\) 的倍数，选取包含 \(x\) 的三个相邻倍数，最小者至少 \(x-2g\ge L-2g>F\)，均可表示。

否则 \(A\) 恰有两个 \(g\) 的倍数，(D) 迫使 \(B\) 也只有两个。因此
\[
a=vg,\quad b=(v+1)g,\quad c<(v+2)g.
\]
同时，\(g>1\)、\(c\not\equiv0\pmod g\)、\(|A|\ge|B|\ge g+1\)，以及 \(\min A>x-2g\ge L-2g\)。两个 \(g\) 的倍数本身均可表示，只需一个非零剩余类中的点。

* 若 \(v=1\)，则 \(a=g\)。选取 \(A\) 中与 \(c\) 同余模 \(g\) 的点，因其大于 \(c\)，可表示。
* 若 \(v\ge3\)，则
  \(F+c<L-(v-1)g\le L-2g<\min A\)。任何 \(c\bmod g\) 的点均可表示。
* 若 \(v=2\) 且 \(c\le3g\)，则 \(F=g\)，所以 \(F+c\le4g<\min A\)，同样成立。
* 若 \(v=2\) 且 \(c>3g\)，写 \(c=3g+s\)、\(1\le s<g\)，以及 \(x=6jg\)。两个数
  \[
  y=x-g+s=c+2g(3j-2),\qquad
  z=x+s=c+3g(2j-1)
  \]
  均可表示，且 \(y<x<z\)、\(z-y=g\)。包含 \(x\)、长度至少 \(g+1\) 的整数区间不可能同时避开 \(y,z\)。其中至少一个提供第三点。

所有情形完成。

## 6. 小下指标判据：\(l\le3(t-1)\)

**引理 S。** 令 \(t=\lfloor n/k\rfloor\ge2\)。若 \(l\le3(t-1)\)，则所有 \(I\subseteq B\) 均满足 (H)。

\(|I|\le3\) 已由上一节证明。以下记 \(r=|I|\ge4\)、\(m=\max I\)。若 \(m\le d\)，将每个 \(b\in I\) 沿 \(m\) 平移到 \([N,N+m-1]\)，得到 \(r\) 个不同的可表示整数。

否则 \(m>d\)，记 \(e=m-d\le l\)。在 \(\mathbb Z/m\mathbb Z\) 中令 \(S=I\bmod m\)、\(W=A\bmod m\)。有 \(|S|=r\)、\(|W|=d\) 和 \(0\in S\)。

因 \(N>(t-1)k\ge(t-1)m\)，所有 \(y\in A\) 且 \(y\bmod m\in tS\) 的数都可表示：选非零剩余类的生成元及零剩余类的空和，可得 \(0\le z<tm\)，若 \(z>y\)，则 \(z\ge y+m>tm\)，矛盾。

令 \(H=\operatorname{Stab}(tS)=\{0,g,\ldots,m-g\}\)、\(h=m/g\)。若 \(S,tS\) 分别占据 \(z,w\) 个 \(H\) 陪集，Kneser 迭代式给出
\[
w\ge tz-(t-1)\ge2z-1.
\]
设 \(v=h-\lfloor l/g\rfloor\ge1\)。因 \(S\) 来自 \([l+1,m]\)，每个陪集至多有 \(v\) 个 \(S\) 元素，所以 \(r\le zv\)。\(W\) 每个陪集至少有 \(v-1\) 个点；零陪集由 (D) 至少有 \(v\) 个点。

当 \(v\ge2\)，
\[
|W\cap tS|\ge v+(2z-2)(v-1)\ge zv\ge r.
\]
当 \(v=1\)，有 \(z=r\)。若 \(d\ge g\)，每个陪集至少被 \(W\) 命中一次，结论成立。若 \(d<g\)，\(W\) 占据 \(d\) 个不同陪集，总陪集数为 \(g\)，于是
\[
|W\cap tS|\ge tr-(t-1)-(g-d)\ge r,
\]
最后一步使用
\[
(t-1)(r-1)\ge3(t-1)\ge l\ge m-d\ge g-d.
\]
引理 S 得证。

## 7. 多项式性给出的层数限制

假设 \(d\ge2\)，令 \(t=\lfloor n/k\rfloor\ge2\)。由于
\[
(t-1)k<N\le tk,\qquad U<(t+1)k,
\]
由 (D) 迫使 \(tk\in A\)。于是
\[
N\ge tk-d+1.\tag{7.1}
\]
取 \(b=\lfloor(N-1)/t\rfloor\)，则 \(b\le k-1\)。而 \(b\ge l+1\)：否则 \(N\le t(l+1)\)，从而 \(t(l+1)\) 和 \(tk\) 均在 \(A\) 内，两者相距 \(t(d-1)>d-1\)，矛盾。

因为 \(tb<N\)，这个分母指标 \(b\) 的某个倍数进入 \(A\) 至少要求
\((t+1)b\le N+d-1\)。写 \(N=tb+v\)、\(1\le v\le t\)，得 \(b\le d+t-1\)，所以
\[
N\le t(d+t).\tag{7.2}
\]
合并两式即得
\[
\boxed{k\ge(t+1)(l-t+1),}\tag{7.3}
\]
以及
\[
\boxed{
 tk+l\le n\le
 \min\{(t+1)k-1,(t+1)k-tl+t^2-1\}.
}\tag{7.4}
\]

## 8. 唯一两条边界的显式单射

假设 \(t=2\)、\(l\ge3\)。以下只需处理右端子集 \(I\subseteq[d+1,k]\)，因为其余子集均由引理 M 处理。

### 8.1 \(k=3l-3\)

由 (7.4)，必须 \(n=7l-6\)。令 \(g=l-1\ge2\)，则
\[
k=3g,\quad d=2g-1,\quad A=[4g+2,6g],\quad I\subseteq[2g,3g].
\]
若 \(3g\in I\)，用单射
\[
c\longmapsto c+3g.
\]
其像属于 \([5g,6g]\subseteq A\)，且全部可表示。

若 \(3g\notin I\)，用
\[
c\longmapsto
\begin{cases}
6g,&c=2g,\\
2c,&c>2g.
\end{cases}
\]
特殊像是 \(3(2g)\)，其他像为互异的偶数，均不超过 \(6g-2\) 且不小于 \(4g+2\)，因此互异且都在 \(A\)。

### 8.2 \(k=3l-2\)

由 (7.4)，\(n\in\{7l-4,7l-3\}\)。前一个不可能满足多项式性：对 \(b=2l-1\in B\)，此时
\[
A=[4l-1,6l-4],\qquad 2b=4l-2<N,\quad3b=6l-3>U,
\]
没有任何 \(b\) 的倍数在 \(A\) 中。

因此 \(n=7l-3\)，且
\[
A=[4l,6l-3],\qquad I\subseteq[2l-1,3l-2].
\]
使用单射
\[
c\longmapsto
\begin{cases}
3c=6l-3,&c=2l-1,\\
2c,&c\ge2l.
\end{cases}
\]
特殊像为奇数，其他像为 \([4l,6l-4]\) 内的互异偶数，故它们互不重叠。两条边界均满足 (H)。

## 9. 全部参数的闭合分类

若 \(d=1\)，商为 \((1-q^{n-k+1})/(1-q^k)\)，多项式性迫使 \(k\mid n-k+1\)，所以是非负系数几何级数。

以下 \(d\ge2\)，令 \(t=\lfloor n/k\rfloor\ge2\)。

1. 若 \(l\le3(t-1)\)，引理 S 给出所有子集的 (H)。
2. 若 \(k\ge3l-1\)，引理 M 与 R 共同给出所有子集的 (H)。
3. 假设前两种都不满足，即 \(l\ge3t-2\)、\(k<3l-1\)。由 (7.3)，
   \[
   \begin{aligned}
   k-(3l-1)
   &\ge(t-2)l-t^2+2\\
   &\ge(t-2)(3t-2)-t^2+2\\
   &=2(t-1)(t-3).
   \end{aligned}
   \]
   如果 \(t\ge3\)，右侧非负，与 \(k<3l-1\) 矛盾。因此 \(t=2\)。再由 (7.3)，\(k\ge3l-3\)，所以只可能
   \[
   k=3l-3\quad\text{或}\quad k=3l-2.
   \]
   此时 \(l\ge4\)，第 8 节的两条边界单射适用；再与 M 合并，全部子集满足 (H)。

三个分支覆盖所有参数。应用外部输入 G，得到 \(P(q)\in\mathbb Z_{\ge0}[q]\)。主命题证毕。

## 10. 与原猜想全部合法参数的关系

对于 \(0\le k,l\le n\)，利用 \({n\brack j}_q={n\brack n-j}_q\)，可把两个下指标都化到 \([0,\lfloor n/2\rfloor]\)。若它们相等，则商为 1；若分子的下指标严格小于分母的下指标，则商的次数为负，不可能是非零多项式。因此需要证明的非平凡情形恰为本文的 \(0\le l<k\le n/2\)。

## 11. 审计说明及已排除的错误路线

* 这份证明没有使用“整个碰撞组都被一个碰撞对的最大公因子整除”的错误推断。
* 右端引理的区间截断采用式 (4.4) 的精确最小值，而不是把区间外的点计入命中数。
* 新引理使用混合和集 \(S+T\)，而不是未经证明的“二重和集总能命中”命题。后者确实有反例：\((n,k,l)=(15,4,2)\)、\(I=\{3,4\}\) 时，\(A=\{12,13\}\)，模 4 的 \(R+R=\{0,2,3\}\) 只命中 12；但 13=3+3+3+4 属于半群。
* 原先把 \(n\ge3k\) 证明撤回的理由，并未击中原证明中的“共同右端的两个区间取最小容量”步骤。本稿第 4 节明确写出完整公式，并在更强的全范围论证中使用它。
* “完整”在这里指所有参数分支在稿内均有证明，不指已经通过外部审稿。外部审阅应尤其核查第 3 节的新混合计数与第 9 节的分类闭合。

计算核验的精确范围和统计见随附 JSON。脚本中对每个生成的命中集合，都使用独立的半群动态规划复查；对选定实例还检查完整、未经截断的多项式乘法恒等式。新引理另有不要求完整多项式性的局部假设审计。

## 参考文献

[1] M. Gatzweiler, F. Levicán-Santibáñez, A. Yoshida, *Cyclotomic generating functions, empty weighted complete intersections and positivity*, arXiv:2603.22226, Propositions 3.3 and 3.6. https://arxiv.org/html/2603.22226v1

[2] M. DeVos, *A short proof of Kneser's addition theorem for abelian groups*, arXiv:1303.3539, Theorem 1. https://arxiv.org/html/1303.3539v1

[3] M. Gatzweiler, C. Krattenthaler, *A positivity conjecture for a quotient of q-binomial coefficients*, Ramanujan Journal 69, Article 13 (2026); arXiv:2502.06032. https://arxiv.org/abs/2502.06032
