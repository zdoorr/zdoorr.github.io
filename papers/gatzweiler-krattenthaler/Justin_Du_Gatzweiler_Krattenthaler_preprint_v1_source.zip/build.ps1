$ErrorActionPreference = 'Stop'
$paperStem = 'Justin_Du_Gatzweiler_Krattenthaler_preprint_v1'
$paperSource = Join-Path $PSScriptRoot ($paperStem + '.tex')
$paperBuildDir = Join-Path $PSScriptRoot 'build'
New-Item -ItemType Directory -Path $paperBuildDir -Force | Out-Null
for ($paperPass = 1; $paperPass -le 3; $paperPass++) {
    & pdflatex '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' '-no-shell-escape' "-output-directory=$paperBuildDir" $paperSource
    if ($LASTEXITCODE -ne 0) {
        throw "pdfLaTeX failed on pass $paperPass."
    }
}
Copy-Item -LiteralPath (Join-Path $paperBuildDir ($paperStem + '.pdf')) -Destination (Join-Path $PSScriptRoot ($paperStem + '.pdf')) -Force
Write-Output 'Preprint PDF rebuilt successfully.'
