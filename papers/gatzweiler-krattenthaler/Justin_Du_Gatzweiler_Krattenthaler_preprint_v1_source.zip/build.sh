#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
paper_stem=Justin_Du_Gatzweiler_Krattenthaler_preprint_v1
mkdir -p build
for paper_pass in 1 2 3; do
  pdflatex -interaction=nonstopmode -halt-on-error -file-line-error -no-shell-escape \
    -output-directory=build "$paper_stem.tex"
done
cp "build/$paper_stem.pdf" "$paper_stem.pdf"
printf '%s\n' 'Preprint PDF rebuilt successfully.'
