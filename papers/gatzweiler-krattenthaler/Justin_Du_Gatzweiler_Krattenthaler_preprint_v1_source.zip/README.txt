A candidate proof of the Gatzweiler-Krattenthaler positivity conjecture
Justin Du
Preprint, version 1 | 11 November 2026
Contact: fbphdu@gmail.com

CONTENTS

Justin_Du_Gatzweiler_Krattenthaler_preprint_v1.tex
    Editable, self-contained LaTeX manuscript. The bibliography is embedded.
Justin_Du_Gatzweiler_Krattenthaler_preprint_v1.pdf
    The compiled 14-page preprint.
build.ps1 / build.sh
    Three-pass PDF build commands for Windows PowerShell or a POSIX shell.
verification/
    The ten original supplementary files, unchanged, including the Chinese
    proof draft, both checking programs, original audit results, and SHA256.json.
verification/rerun/
    Results of the two checking programs rerun during preparation of this release.
original_materials/
    The supplied complete_proof.md and mixed_sumset_completion_verified.zip,
    preserved byte for byte.
release_checks.json
    Build, input-integrity, and reproduction checks for this release.
SHA256SUMS.txt
    SHA-256 checksums for the other files in this package.

BUILDING THE PAPER

Use a current TeX Live or MiKTeX installation with pdfLaTeX. Required packages:
fontenc, inputenc, lmodern, geometry, amsmath, amssymb, amsthm, mathtools,
booktabs, tabularx, array, enumitem, fancyhdr, microtype, xurl, and hyperref.
No network access, shell escape, BibTeX run, external fonts, or figures are
required once these standard packages are installed.

Windows:
    powershell -ExecutionPolicy Bypass -File .\build.ps1

Linux or macOS:
    sh build.sh

Alternatively run pdfLaTeX on the .tex file three times. Recompiled PDFs may
have different timestamps and file hashes from the included PDF.

REPRODUCING THE ORIGINAL VERIFICATION

Python 3.10 or newer and its standard library are sufficient. From verification/,
run each command below as a single line:

python verify_mixed_completion.py --k-max 16 --random-cases 6000 --seed 202611103 --out audit_main_rerun.json
python audit_local_mixed.py --cases 12000 --seed 202611102 --out audit_local_rerun.json

The first command includes an exhaustive scan for 2 <= k <= 16, 1 <= l < k,
and 2k <= n <= 7k, plus selected random subsets and boundary checks. Its
3,745,276 subset checks all passed. The local audit generated 12,000 inputs;
9,840 met its local hypothesis and passed, while 2,160 did not meet that
hypothesis and were excluded. Both reruns agree with the supplied JSON
results in every field except elapsed_seconds.

The paper gives the infinite-parameter argument in full. These finite checks
are supplementary error checks, not premises of the proof. In particular,
the small-cardinality code checks the conclusion by a semigroup oracle;
the corresponding mathematical proof is in Section 5 of the paper.

REVIEW STATUS AND AUTHORSHIP

This is a candidate proof, with the two external mathematical inputs cited
in Section 2. This release includes AI-assisted mathematical review,
exposition, reference checking, verification reruns, and typesetting.
External human peer review and proof-assistant formalization are not supplied.
No bibliographic priority claim is made. See the appendix for the disclosure.

The original input files have not been modified.
