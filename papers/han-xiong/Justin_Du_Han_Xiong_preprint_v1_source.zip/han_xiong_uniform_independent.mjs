/**
 * Independent exact BigInt verifier for the uniform Han--Xiong kernel.
 * Run: node han_xiong_uniform_independent.mjs
 *
 * Q_a=(1-q^(2a-1))(1-q^(2a))-q^(3a+1)+q^(4a)+q^(8a+4).
 * Claim: Q_a/D4 is coefficientwise nonnegative for every integer a>=3.
 *
 * This implementation uses a partial-fraction formula for p4(n), not the
 * Python verifier's residue-cubic construction. It verifies that formula
 * by an exact polynomial identity, then expands each UNBOUNDED parameter
 * region symbolically with BigInt coefficients. No sampled x,y values are
 * used to establish positivity. The mathematical coverage of the regions
 * must be read together with the proof. This is not a Lean formalization.
 */

function check(condition, message) {
  if (!condition) throw new Error(message);
}

function trim(a) {
  while (a.length > 1 && a.at(-1) === 0n) a.pop();
  return a;
}
function mul(a, b) {
  const out = Array(a.length + b.length - 1).fill(0n);
  for (let i = 0; i < a.length; i++)
    for (let j = 0; j < b.length; j++) out[i+j] += a[i]*b[j];
  return trim(out);
}
function power(a, n) {
  let out = [1n];
  for (let i = 0; i < n; i++) out = mul(out, a);
  return out;
}
function addTo(out, a, scale=1n) {
  for (let i=0; i<a.length; i++) out[i] = (out[i] ?? 0n) + scale*a[i];
}
function exactQuotient(numerator, denominator) {
  const rem = [...numerator], d = denominator.length-1;
  const out = Array(numerator.length-denominator.length+1).fill(0n);
  for (let i=rem.length-1; i>=d; i--) {
    check(rem[i] % denominator[d] === 0n, 'Nonintegral quotient');
    const value = rem[i]/denominator[d];
    out[i-d] = value;
    for (let j=0; j<=d; j++) rem[i-d+j] -= value*denominator[j];
  }
  check(rem.every(x=>x===0n), 'Polynomial division remainder');
  return trim(out);
}

// Check the complete partial-fraction identity for 288/D4.
// Coefficients for n>=0 are then exactly
// 288*p4(n)=2n^3+30n^2+135n+175+9*(-1)^n*(n+5)
//            +32*sigma3(n)+36*sigma4(n),
// sigma3=(1,0,-1) periodically; sigma4=(1,0,-1,0) periodically.
const minus = [1n,-1n], plus = [1n,1n];
const cyclo3 = [1n,1n,1n], cyclo4 = [1n,0n,1n];
const D4 = mul(mul(power(minus,4),power(plus,2)),mul(cyclo3,cyclo4));
const fractionTerms = [
  [[12n],power(minus,4)], [[36n],power(minus,3)],
  [[59n],power(minus,2)], [[68n],minus],
  [[9n],power(plus,2)], [[36n],plus],
  [[32n,32n],cyclo3], [[36n],cyclo4],
];
const identity = [];
for (const [numerator, denominator] of fractionTerms)
  addTo(identity,mul(numerator,exactQuotient(D4,denominator)));
check(identity[0]===288n && identity.slice(1).every(x=>x===0n),
      'p4 partial-fraction identity failed');

// Monomial order: 1,x,y,x^2,xy,y^2,x^3,x^2*y,x*y^2,y^3.
function p4Times288([alpha,beta,gamma]) {
  check(Math.min(alpha,beta,gamma)>=0, 'Negative p4 argument');
  check(alpha%12===0 && beta%12===0, 'Nonconstant residue');
  const A=BigInt(alpha), B=BigInt(beta), C=BigInt(gamma);
  const sign=gamma%2===0?1n:-1n;
  const sigma3=[1n,0n,-1n][gamma%3];
  const sigma4=[1n,0n,-1n,0n][gamma%4];
  const linear=135n+9n*sign;
  return [
    2n*C*C*C+30n*C*C+linear*C+175n+45n*sign+32n*sigma3+36n*sigma4,
    A*(6n*C*C+60n*C+linear), B*(6n*C*C+60n*C+linear),
    A*A*(6n*C+30n), A*B*(12n*C+60n), B*B*(6n*C+30n),
    2n*A*A*A, 6n*A*A*B, 6n*A*B*B, 2n*B*B*B,
  ];
}

const add=(p,q)=>p.map((v,i)=>v+q[i]);
const scale=(p,w)=>p.map(v=>v*w);
const cnst=c=>[0,0,c];
const regions=[];

// Region I1: u=n-3a-1>=0, t=4a-2-n>=0, so a=u+t+3.
for(let r=0;r<12;r++) for(let v=0;v<12;v++) {
  const u=[12,0,r], t=[0,12,v], a=add(add(u,t),cnst(3));
  regions.push(['I1',a,add(add(scale(a,3),cnst(1)),u)]);
}
// Region I2: n=4a-1, a>=3.
for(let r=0;r<12;r++) {
  const a=[12,0,r+3];
  regions.push(['I2',a,add(scale(a,4),cnst(-1))]);
}
// Region I3: n=4a+4b+u, 0<=u<=3, 0<=b<=a, a>=3.
// Let t=a-b. If b>=3 put b=3+12x+r, t=12y+v;
// otherwise b is 0,1,2 and a=3+12x+r.
for(let u=0;u<4;u++) for(let r=0;r<12;r++) for(let v=0;v<12;v++) {
  const b=[12,0,r+3], t=[0,12,v], a=add(b,t);
  regions.push(['I3a',a,add(add(scale(a,4),scale(b,4)),cnst(u))]);
}
for(let u=0;u<4;u++) for(let b=0;b<3;b++) for(let r=0;r<12;r++) {
  const a=[12,0,r+3];
  regions.push(['I3b',a,add(scale(a,4),cnst(4*b+u))]);
}
// Tail: a=12A+r+3, n=8a+4+12T+v; A,T>=0.
// T<=3A: T=3x+b, A=x+y+ceil(b/3), 0<=b<=2.
// T>=3A: T=3A+V. V=0,1,2 or V=3+y.
// The shared boundary T=3A is covered twice; no points are omitted.
for(let r=0;r<12;r++) for(let v=0;v<12;v++) {
  const pushTail=(name,A,T)=>{
    const a=add(scale(A,12),cnst(r+3));
    regions.push([name,a,add(add(scale(a,8),scale(T,12)),cnst(4+v))]);
  };
  for(let b=0;b<3;b++)
    pushTail('I4lower',[1,1,b===0?0:1],[3,0,b]);
  for(let V=0;V<3;V++) pushTail('I4face',[1,0,0],[3,0,V]);
  pushTail('I4upper',[1,0,0],[3,1,3]);
}

const kernelTerms=[[0,0,1],[2,-1,-1],[2,0,-1],[3,1,-1],
                   [4,-1,1],[4,0,1],[8,4,1]];
let count=0, nonzero=0, minimum=null;
const groupCounts={};
for(const [name,a,n] of regions) {
  const polynomial=Array(10).fill(0n);
  for(const [s,t,w] of kernelTerms) {
    const arg=n.map((z,i)=>z-s*a[i]-(i===2?t:0));
    if(arg[0]<=0 && arg[1]<=0 && arg[2]<0) continue;
    check(Math.min(...arg)>=0,
      `Support boundary crossed: ${JSON.stringify({name,a,n,arg})}`);
    const term=p4Times288(arg);
    for(let i=0;i<10;i++) polynomial[i]+=BigInt(w)*term[i];
  }
  check(polynomial.every(c=>c>=0n),
    `Negative coefficient: ${JSON.stringify({name,a,n,polynomial:polynomial.map(String)})}`);
  groupCounts[name]=(groupCounts[name]??0)+1;
  count++;
  for(const c of polynomial) if(c!==0n) {
    nonzero++;
    if(minimum===null || c<minimum) minimum=c;
  }
}
check(count===1884,'Unexpected case count');
check(nonzero===15312,'Unexpected nonzero coefficient count');
check(minimum===3168n,'Unexpected minimum (288 times coefficient)');

console.log('Exact p4 partial-fraction identity verified.');
console.log('Regions:',JSON.stringify(groupCounts));
console.log('Unbounded symbolic cases:',count,'nonzero coefficients:',nonzero);
console.log('Minimum nonzero coefficient for 288*[q^n](Q_a/D4):',minimum.toString());
console.log('Every symbolic coefficient is nonnegative, with no support boundary crossed.');
console.log('For n<3a+1, positivity follows from the positive product decomposition.');
console.log('PASS: all integer a>=3, all integer n>=0 (ordinary exact computation).');
