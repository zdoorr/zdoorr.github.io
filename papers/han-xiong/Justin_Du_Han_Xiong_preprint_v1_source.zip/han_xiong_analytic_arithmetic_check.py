"""Supplementary exact arithmetic audit of the analytic Han--Xiong draft.

The main proof in full_paper_content.py, version 0.2, is human-checkable:
it gives exact coefficient formulas, error bounds, and elementary polynomial
inequalities.  This standalone standard-library script only cross-checks
the displayed arithmetic.  It does NOT sample a finite range of parameters
and infer positivity beyond that range, and is not a proof-assistant proof.

Every variable-kernel calculation below is a polynomial identity in symbolic
variables.  Coefficients are fractions with arbitrary-precision integers.
The sole finite coefficient list is the explicitly displayed twenty initial
coefficients of the fixed first-index kernel, whose entire tail has its own
analytic proof.

Run with: python -I han_xiong_analytic_arithmetic_check.py
No imports from the other verification programs or manuscript are needed.
"""

from collections import Counter, defaultdict
from fractions import Fraction as F


class Poly:
    """Sparse polynomials over Q in three independent formal variables."""

    def __init__(self, terms=None):
        self.terms = {
            tuple(m): F(c) for m, c in (terms or {}).items() if c
        }

    @staticmethod
    def coerce(value):
        if isinstance(value, Poly):
            return value
        return Poly({(0, 0, 0): F(value)})

    def __add__(self, other):
        out = defaultdict(F)
        for p in (self, self.coerce(other)):
            for mon, coefficient in p.terms.items():
                out[mon] += coefficient
        return Poly(out)

    __radd__ = __add__

    def __neg__(self):
        return Poly({m: -c for m, c in self.terms.items()})

    def __sub__(self, other):
        return self + (-self.coerce(other))

    def __rsub__(self, other):
        return self.coerce(other) + (-self)

    def __mul__(self, other):
        other = self.coerce(other)
        out = defaultdict(F)
        for am, ac in self.terms.items():
            for bm, bc in other.terms.items():
                out[tuple(a + b for a, b in zip(am, bm))] += ac * bc
        return Poly(out)

    __rmul__ = __mul__

    def __truediv__(self, scalar):
        return self * (F(1) / F(scalar))

    def __pow__(self, exponent):
        if not isinstance(exponent, int) or exponent < 0:
            raise ValueError("Polynomial powers must be nonnegative integers")
        out = self.coerce(1)
        for _ in range(exponent):
            out = out * self
        return out

    def __eq__(self, other):
        return self.terms == self.coerce(other).terms

    def diff(self, axis):
        out = {}
        for mon, coefficient in self.terms.items():
            if mon[axis]:
                reduced = list(mon)
                reduced[axis] -= 1
                out[tuple(reduced)] = coefficient * mon[axis]
        return Poly(out)

    def subs(self, replacements):
        """Simultaneous substitution, leaving unlisted variables unchanged."""
        variables = [X, Y, Z]
        for axis, expression in replacements.items():
            variables[axis] = self.coerce(expression)
        out = self.coerce(0)
        for mon, coefficient in self.terms.items():
            term = self.coerce(coefficient)
            for variable, exponent in zip(variables, mon):
                term *= variable ** exponent
            out += term
        return out

    def __repr__(self):
        return repr({m: str(c) for m, c in sorted(self.terms.items())})


X = Poly({(1, 0, 0): 1})
Y = Poly({(0, 1, 0): 1})
Z = Poly({(0, 0, 1): 1})
CHECKS = Counter()


def identity(label, actual, expected, category="polynomial identities"):
    actual, expected = Poly.coerce(actual), Poly.coerce(expected)
    if actual != expected:
        raise AssertionError(f"{label}: nonzero difference {actual - expected}")
    CHECKS[category] += 1


def positive_coefficients(label, polynomial, strict_constant=True):
    """Certify this explicit polynomial is nonnegative on the positive cone."""
    p = Poly.coerce(polynomial)
    if any(c < 0 for c in p.terms.values()):
        raise AssertionError(f"{label}: negative displayed coefficient {p}")
    if strict_constant and p.terms.get((0, 0, 0), F(0)) <= 0:
        raise AssertionError(f"{label}: constant coefficient is not positive")
    CHECKS["displayed positive polynomials"] += 1


def exact_univariate_quotient(numerator, denominator):
    """Exact long division in Q[X]; a remainder is an audit failure."""
    numerator, denominator = map(Poly.coerce, (numerator, denominator))
    for p in (numerator, denominator):
        if any(mon[1:] != (0, 0) for mon in p.terms):
            raise ValueError("Expected univariate polynomial")
    if not denominator.terms:
        raise ZeroDivisionError
    d = max(mon[0] for mon in denominator.terms)
    lead = denominator.terms[(d, 0, 0)]
    remainder, quotient = numerator, Poly()
    while remainder.terms:
        e = max(mon[0] for mon in remainder.terms)
        if e < d:
            raise AssertionError(f"Nonzero exact-division remainder: {remainder}")
        term = X ** (e - d) * (remainder.terms[(e, 0, 0)] / lead)
        quotient += term
        remainder -= term * denominator
    return quotient


def f(t):
    return 2*t**3 + 30*t**2 + 135*t + 175


def g(t):
    return 9*t + 113


def lower_288(pairs, active_count):
    """288 times the analytic lower bound, with n=Y and parameter=X."""
    return sum(
        weight * f(Y - exponent) - abs(weight) * g(Y - exponent)
        for exponent, weight in pairs[:active_count]
    )


def at_endpoint(polynomial, base, slope, intercept):
    """Parameter=base+X; n=slope*(base+X)+intercept."""
    return polynomial.subs({0: X + base, 1: slope*(X + base) + intercept})


def audit_p4():
    q, n = X, Y
    d4 = (1-q)*(1-q**2)*(1-q**3)*(1-q**4)
    partial_fractions = [
        (F(1, 24), (1-q)**4),
        (F(1, 8), (1-q)**3),
        (F(59, 288), (1-q)**2),
        (F(17, 72), 1-q),
        (F(1, 32), (1+q)**2),
        (F(1, 8), 1+q),
        ((1+q)/9, 1+q+q**2),
        (F(1, 8), 1+q**2),
    ]
    cleared = sum(
        numerator * exact_univariate_quotient(d4, denominator)
        for numerator, denominator in partial_fractions
    )
    identity("(5.3) partial fractions, cleared by D4", cleared, 1)
    pole_at_one = (
        (n+3)*(n+2)*(n+1)/144
        + (n+2)*(n+1)/16 + 59*(n+1)/288 + F(17, 72)
    )
    identity("(5.2) cubic polynomial part", pole_at_one, f(n)/288)
    identity("(5.2) alternating amplitude", (n+1)/32+F(1, 8), (n+5)/32)
    identity("delta3 generating function", (1-q**2)*(1+q+q**2), (1+q)*(1-q**3))
    identity("delta4 generating function", (1-q**2)*(1+q**2), 1-q**4)
    identity("periodic error constant", F(1, 9)+F(1, 8), F(17, 72))
    identity("288 E(t)", 288*((n+5)/32+F(17, 72)), g(n))


def audit_uniform_kernel():
    a, n = X, Y
    pairs = [(0,1),(2*a-1,-1),(2*a,-1),(3*a+1,-1),
             (4*a-1,1),(4*a,1),(8*a+4,1)]
    l4, l5, l6, l7 = [lower_288(pairs, count) for count in (4,5,6,7)]
    expected_l4 = (-4*n**3+(42*a-60)*n**2+(-102*a**2+408*a-318)*n
                   +86*a**3-480*a**2+978*a-862)
    identity("(5.7) 288 L4", l4, expected_l4)
    h = -6*n**2+(42*a-60)*n-51*a**2+204*a-159
    identity("144 derivative of L4", l4.diff(1)/2, h)
    for label, slope, intercept, expected in [
        ("left",3,1,54+156*X+21*X**2),
        ("right",4,-2,54+102*X+21*X**2),
    ]:
        identity(f"Q derivative {label} endpoint", at_endpoint(h,3,slope,intercept), expected)
        positive_coefficients(f"Q derivative {label} endpoint", expected)
    identity("Q derivative is a concave quadratic", h.diff(1).diff(1), -12)
    expected_l6 = (-6*(a-1)*n**2+(90*a**2-120*a)*n
                   -170*a**3+576*a**2-294*a-580)
    identity("(5.10) 288 L6", l6, expected_l6)
    identity("L6 second derivative", l6.diff(1).diff(1)/288, -(a-1)/24)
    for label, poly, slope, intercept, expected in [
        ("(5.8)",l4,3,1,2554+2904*X+696*X**2+50*X**3),
        ("(5.9)",l5,4,-1,2666+3210*X+996*X**2+94*X**3),
        ("(5.11) left",l6,4,0,2804+3396*X+1038*X**2+94*X**3),
        ("(5.11) right",l6,8,3,2534+3954*X+1476*X**2+166*X**3),
    ]:
        identity(f"Q endpoint {label}", at_endpoint(poly,3,slope,intercept), expected)
        positive_coefficients(f"Q endpoint {label}", expected)
    t = Y
    centered = t**3-(6*a**2+21)*t+78*a**3+6*a**2-156*a-301
    identity("(5.12) Q centered tail", l7.subs({1:9*a-2+t})/2, centered)
    identity("Q tail coefficient comparison", (F(25,3)*a**2-6*a**2-21).subs({0:X+3}),
             14*X+F(7,3)*X**2)
    positive_coefficients("Q tail coefficient comparison",14*X+F(7,3)*X**2,False)
    identity("Q tail cubic factorization",
             t**3-F(25,3)*a**2*t+F(250,27)*a**3,
             (t-F(5,3)*a)**2*(t+F(10,3)*a))
    identity("Q tail relaxed cubic constant",10*a**3-F(250,27)*a**3,F(20,27)*a**3)
    bound = 68*a**3+6*a**2-156*a-301
    identity("Q tail constant after subtracting 10 a^3",
             centered.subs({1:0})-10*a**3,bound)
    expected = 1121+1716*X+618*X**2+68*X**3
    identity("(5.13) shifted Q tail bound",bound.subs({0:X+3}),expected)
    positive_coefficients("Q final tail bound",expected)


def audit_old_variable_kernel():
    j, n = X, Y
    pairs = [(0,1),(4*j-1,-1),(4*j,-1),(7*j,-2),
             (8*j-1,1),(8*j,2),(16*j+4,1)]
    m4,m5,m6,m7 = [lower_288(pairs,count) for count in (4,5,6,7)]
    expected_m4 = (-6*n**3+(132*j-96)*n**2+(-780*j**2+1368*j-516)*n
                   +1628*j**3-3996*j**2+3432*j-1266)
    identity("(6.3) 288 M4",m4,expected_m4)
    derivative = m4.diff(1)
    for label,slope,intercept,expected in [
        ("left",7,0,276+768*X+186*X**2),
        ("right",8,-2,276+600*X+180*X**2),
    ]:
        identity(f"Kj derivative {label} endpoint",at_endpoint(derivative,2,slope,intercept),expected)
        positive_coefficients(f"Kj derivative {label} endpoint",expected)
    identity("Kj first derivative is concave",derivative.diff(1).diff(1),-36)
    expected_m6 = (-12*j*n**2+(372*j**2-168*j-72)*n
                   -1444*j**3+2148*j**2-120*j-922)
    identity("(6.6) 288 M6",m6,expected_m6)
    identity("M6 second derivative",m6.diff(1).diff(1)/288,-j/12)
    for label,poly,slope,intercept,expected in [
        ("(6.4)",m4,7,0,6502+10260*X+4344*X**2+578*X**3),
        ("(6.5)",m5,8,-1,6750+11124*X+5208*X**2+764*X**3),
        ("(6.7) left",m6,8,0,7014+11688*X+5388*X**2+764*X**3),
        ("(6.7) right",m6,16,3,4278+13044*X+8040*X**2+1436*X**3),
    ]:
        identity(f"Kj endpoint {label}",at_endpoint(poly,2,slope,intercept),expected)
        positive_coefficients(f"Kj endpoint {label}",expected)
    t,s = Y,Z
    b = 6*j**2+24*j+16
    c = 1380*j**3-816*j**2-1308*j-918
    identity("(6.8) Kj centered tail",m7.subs({1:18*j-1+t}),2*t**3-6*b*t+c)
    identity("Kj tail cubic factorization, s=sqrt(B)",
             2*t**3-6*s**2*t,2*(t-s)**2*(t+2*s)-4*s**3)
    square_bound = ((4*j+2)**2-b).subs({0:X+2})
    identity("Kj square-root upper bound",square_bound,12+32*X+10*X**2)
    positive_coefficients("Kj square-root upper bound",square_bound)
    positive_coefficients("B >= j^2",b-j**2)
    bound = 1284*j**3-1248*j**2-1756*j-1046
    identity("(6.9) C minus 4 B (4j+2)",c-4*b*(4*j+2),bound)
    expected = 722+8660*X+6456*X**2+1284*X**3
    identity("(6.9) shifted Kj tail bound",bound.subs({0:X+2}),expected)
    positive_coefficients("Kj final tail bound",expected)


def audit_first_index_kernel():
    n=Y
    pairs=[(0,2),(3,-2),(4,-2),(8,2),(20,1)]
    tail=lower_288(pairs,5)/2
    identity("(7.2) Kstar tail cubic",tail,n**3-51*n**2+801*n-3353)
    shifted=tail.subs({1:X+20})
    identity("(7.3) shifted Kstar tail",shifted,X**3+9*X**2-39*X+267)
    identity("(7.3) completed square",shifted,X**3+(3*X-F(13,2))**2+F(899,4))
    partitions=[0]*20
    partitions[0]=1
    for part in range(1,5):
        for degree in range(part,20):
            partitions[degree]+=partitions[degree-part]
    actual=[sum(weight*partitions[n-exponent] for exponent,weight in pairs if exponent<=n)
            for n in range(20)]
    expected=[2,2,4,4,6,6,8,6,10,8,10,8,12,8,12,8,12,8,12,6]
    if actual != expected:
        raise AssertionError(f"(7.1) initial Kstar coefficients: {actual}")
    CHECKS["fixed-kernel initial coefficients"]+=len(expected)


def main():
    audit_p4()
    audit_uniform_kernel()
    audit_old_variable_kernel()
    audit_first_index_kernel()
    print("PASS: supplementary exact arithmetic audit of the analytic proof.")
    for category,count in CHECKS.items():
        print(f"{category}: {count}")
    print("All variable-kernel checks are symbolic identities, with no parameter cutoff.")
    print("No third-party libraries, floating-point arithmetic, or positivity sampling used.")
    print("This cross-check does not replace reading the proof or external review.")


if __name__ == "__main__":
    main()
