A candidate proof of the Han-Xiong 1/2-conjecture
Justin Du
Contact: fbphdu@gmail.com
Preprint, version 1
Manuscript date: 24 October 2026

STATUS
This is a candidate complete proof, released as a preprint for public examination.
It has not undergone external human peer review or proof-assistant formalization.
Generative AI contributed substantially to the proposed argument, text, and
verification programs. The manuscript appendix gives the AI-use disclosure.

CONTENTS
Justin_Du_Han_Xiong_preprint_v1.pdf    The 16-page preprint.
main.tex                            Complete self-contained TeX source.
CITATION.bib                        Suggested bibliographic entry.
verification.json                   Identity and preparation checks for this release.
MANIFEST.sha256                     SHA-256 digests of the included files.
han_xiong_analytic_arithmetic_check.py
                                    Exact checker for the displayed arithmetic.
han_xiong_kernel_certificate.py
han_xiong_kernel_independent.mjs
han_xiong_uniform_kernel_certificate.py
han_xiong_uniform_independent.mjs    Supplementary alternative kernel certificates.
full_m2_symbolic_certificate.json
full_uniform_symbolic_certificate.json
                                    Exported exact certificate data.

BUILD THE PDF
Run twice, in this directory:
  pdflatex -interaction=nonstopmode -halt-on-error -jobname=Justin_Du_Han_Xiong_preprint_v1 main.tex
  pdflatex -interaction=nonstopmode -halt-on-error -jobname=Justin_Du_Han_Xiong_preprint_v1 main.tex
The source uses ordinary LaTeX packages and requires no external images.

ARITHMETIC CHECKS
The Python programs use only the standard library. The .mjs programs require Node.js.
  python -I han_xiong_analytic_arithmetic_check.py
  python -I han_xiong_kernel_certificate.py
  node han_xiong_kernel_independent.mjs
  python -I han_xiong_uniform_kernel_certificate.py
  node han_xiong_uniform_independent.mjs
Run Python with assertions enabled; do not use -O or -OO.
The analytic checker verifies 42 polynomial identities, 17 displayed positive
polynomials, and all 20 displayed initial coefficients of the fixed kernel.
These checks supplement the proof; they are not independent human peer review.

PERSONAL-WEBSITE POSTING
Use the same title and author name in the PDF, webpage, and bibliographic metadata.
Give the paper a stable page with its full abstract and a direct link to this PDF.
Record the actual date of public posting on the webpage. The date printed in the
PDF is the manuscript version date, not a claim that the file was already online.
Retain earlier publicly posted versions when later versions are issued.

VERSION NOTE
Version 1 prepares the checked manuscript for public circulation with author,
contact, and preprint metadata. The mathematical body and displayed equations
are unchanged from the checked source. Internal editing histories are not part
of this public package.
