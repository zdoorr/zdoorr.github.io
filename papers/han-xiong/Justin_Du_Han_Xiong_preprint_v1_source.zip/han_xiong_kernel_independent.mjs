/**
 * Independent exact-integer verification of two Han--Xiong r=1/4 kernels.
 * Run: node han_xiong_kernel_independent.mjs
 *
 * No imports, external packages, floating-point polynomial coefficients,
 * interpolation table, or code from the accompanying Python verifier.
 * Polynomial coefficients use BigInt throughout. The small Number triples
 * below encode affine forms in two UNBOUNDED nonnegative integer variables;
 * they are not sampled values of those variables.
 *
 * D4 = (1-q)(1-q^2)(1-q^3)(1-q^4).
 * Kj = (1-q^(4j-1))(1-q^(4j)) - 2q^(7j) + 2q^(8j) + q^(16j+4).
 * Kstar = 2 - 2q^3 - 2q^4 + 2q^8 + q^20.
 *
 * Mathematical coverage of the finite cone decomposition is explained below
 * and must also be checked in the proof. A successful run verifies all
 * symbolic polynomial coefficients on those cones, not merely a finite set
 * of values of j and n. This is ordinary exact code, not a proof-assistant
 * formalization of the complete theorem.
 */

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function multiplyUnivariate(a, b) {
  const c = Array(a.length + b.length - 1).fill(0n);
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j < b.length; j++) c[i + j] += a[i] * b[j];
  }
  return c;
}

function addShifted(target, source, shift = 0) {
  for (let i = 0; i < source.length; i++) {
    target[i + shift] = (target[i + shift] ?? 0n) + source[i];
  }
}

// C(q) = (1-q^12)^4/D4. This exact polynomial has degree 38.
let cyclotomicNumerator = [1n];
for (let d = 1; d <= 4; d++) {
  const factor = Array(13 - d).fill(0n);
  for (let e = 0; e <= 12 - d; e += d) factor[e] = 1n;
  cyclotomicNumerator = multiplyUnivariate(cyclotomicNumerator, factor);
}
assert(cyclotomicNumerator.length === 39, "Wrong degree of C(q)");

/**
 * Return the coefficients of 6*p4(a*x+b*y+c) in the monomial order
 * 1,x,y,x^2,xy,y^2,x^3,x^2*y,x*y^2,y^3.
 * Here a,b are nonnegative multiples of 12 and c >= 0.
 *
 * Derivation, independent of interpolation:
 * p4(12m+r) = sum_l C[r+12l] binom(m-l+3,3).
 * Since deg C=38, l<=3. The cubic binomial is also zero when
 * m-l is -1,-2,-3, so the formula is exact for EVERY integer m>=0.
 * Each summand is expanded directly using
 * 6*binom(L+3,3)=L^3+6L^2+11L+6.
 */
function p4SixOfAffine([a, b, c]) {
  assert(a % 12 === 0 && b % 12 === 0, "Variable coefficients not divisible by 12");
  assert(Math.min(a, b, c) >= 0, "Negative p4 argument on a purported positive cone");
  const r = c % 12;
  const A = BigInt(a / 12), B = BigInt(b / 12), C = BigInt((c - r) / 12);
  const out = Array(10).fill(0n);
  for (let ell = 0; r + 12 * ell < cyclotomicNumerator.length; ell++) {
    const d = C - BigInt(ell);
    const expansion = [
      d*d*d + 6n*d*d + 11n*d + 6n,
      A*(3n*d*d + 12n*d + 11n),
      B*(3n*d*d + 12n*d + 11n),
      A*A*(3n*d + 6n),
      2n*A*B*(3n*d + 6n),
      B*B*(3n*d + 6n),
      A*A*A, 3n*A*A*B, 3n*A*B*B, B*B*B,
    ];
    const weight = cyclotomicNumerator[r + 12 * ell];
    for (let i = 0; i < 10; i++) out[i] += weight * expansion[i];
  }
  return out;
}

// Affine forms are triples [coefficient of x, coefficient of y, constant].
const plus = (a, b) => a.map((v, i) => v + b[i]);
const times = (a, c) => a.map(v => v * c);
const constant = c => [0, 0, c];

function verifyKernelCone(name, j, n) {
  // An entry [a,b,w] means w*p4(n-a*j-b), with p4(t)=0 for t<0.
  const terms = [[0,0,1], [4,-1,-1], [4,0,-1], [8,-1,1],
                 [7,0,-2], [8,0,2], [16,4,1]];
  const out = Array(10).fill(0n);
  for (const [a, b, weight] of terms) {
    const arg = n.map((v, i) => v - a*j[i] - (i === 2 ? b : 0));
    if (arg[2] < 0 && arg[0] <= 0 && arg[1] <= 0) continue;
    assert(Math.min(...arg) >= 0,
      `Support boundary crossed: ${JSON.stringify({name, j, n, arg})}`);
    const polynomial = p4SixOfAffine(arg);
    for (let i = 0; i < 10; i++) out[i] += BigInt(weight) * polynomial[i];
  }
  assert(out.every(v => v >= 0n),
    `Negative symbolic coefficient: ${JSON.stringify({name, j, n, coefficients:out.map(String)})}`);
  return out;
}

const cones = [];

// I1: 7j <= n <= 8j-2. R=n-7j>=0, T=j-R-2>=0.
for (let r = 0; r < 12; r++) for (let t = 0; t < 12; t++) {
  const R = [12,0,r], T = [0,12,t], j = plus(plus(R,T),constant(2));
  cones.push(["I1", j, plus(times(j,7),R)]);
}

// I2: n=8j-1, j=12x+r+2 covers every j>=2.
for (let r = 0; r < 12; r++) {
  const j = [12,0,r+2];
  cones.push(["I2",j,plus(times(j,8),constant(-1))]);
}

// I3: n=8j+8A+b, 0<=b<=7, j=A+T+1, A,T>=0, A+T>=1.
// I3a has A>=1; I3b has A=0 and T>=1.
for (let b = 0; b < 8; b++) for (let r = 0; r < 12; r++) for (let t = 0; t < 12; t++) {
  const A = [12,0,r+1], T = [0,12,t], j = plus(plus(A,T),constant(1));
  cones.push(["I3a",j,plus(plus(times(j,8),times(A,8)),constant(b))]);
}
for (let b = 0; b < 8; b++) for (let t = 0; t < 12; t++) {
  const j = [12,0,t+2];
  cones.push(["I3b",j,plus(times(j,8),constant(b))]);
}

// I4: n=16j+u, 0<=u<=3.
for (let u = 0; u < 4; u++) for (let r = 0; r < 12; r++) {
  const j = [12,0,r+2];
  cones.push(["I4",j,plus(times(j,16),constant(u))]);
}

// I5: j=12J+r+2, n=16j+4+12T+v, J,T>=0, 0<=r,v<=11.
// Lower cone T<=8J: T=8x+b, J=x+y+ceil(b/8), 0<=b<=7.
// Upper cone T>=8J: T=8J+V. Split V=0,...,4 and V=5+y.
// The overlap T=8J is harmless and no parameter points are omitted.
for (let r = 0; r < 12; r++) for (let v = 0; v < 12; v++) {
  for (let b = 0; b < 8; b++) {
    const J = [1,1,b===0?0:1], T = [8,0,b], j = plus(times(J,12),constant(r+2));
    cones.push(["I5lower",j,plus(plus(times(j,16),times(T,12)),constant(4+v))]);
  }
  for (let V = 0; V <= 4; V++) {
    const J = [1,0,0], T = plus(times(J,8),constant(V)), j = plus(times(J,12),constant(r+2));
    cones.push(["I5face",j,plus(plus(times(j,16),times(T,12)),constant(4+v))]);
  }
  const J = [1,0,0], T = plus(times(J,8),[0,1,5]), j = plus(times(J,12),constant(r+2));
  cones.push(["I5upper",j,plus(plus(times(j,16),times(T,12)),constant(4+v))]);
}

let monomialCount = 0, minimum = null;
const counts = {};
for (const [name,j,n] of cones) {
  const polynomial = verifyKernelCone(name,j,n);
  counts[name] = (counts[name] ?? 0) + 1;
  for (const coefficient of polynomial) if (coefficient !== 0n) {
    monomialCount++;
    if (minimum === null || coefficient < minimum) minimum = coefficient;
  }
}
assert(cones.length === 3468, "Wrong cone count");
assert(monomialCount === 29424, "Wrong nonzero monomial count");
assert(minimum === 72n, "Unexpected minimum nonzero coefficient");

// The n<7j region is mathematical, not a scan:
// (1-q^(4j-1))(1-q^(4j))/D4
// = [4j-1]_q [j]_(q^4) / ((1-q^2)(1-q^3)), a nonnegative series.

// Verify the Kstar positive decomposition by clearing (1-q^12)^4.
const positivePolynomials = [
  [2,2,4,4,6,6,8,6,10,8,10,8],
  [12,8,12,8,12,8,12,6,13,7,12,7],
  [3,0,5,3,9,8,15,15,23,24,33,35],
  [42,48,54,60,66,72,78,84,90,96,102,108],
].map(row => row.map(BigInt));
assert(positivePolynomials.every(row => row.every(c => c >= 0n)), "Negative Kstar certificate entry");
const oneMinusQ12 = [1n,...Array(11).fill(0n),-1n];
const powers = [[1n]];
for (let t = 1; t <= 4; t++) powers.push(multiplyUnivariate(powers[t-1],oneMinusQ12));
const rhs = [];
for (let t = 0; t <= 3; t++) {
  addShifted(rhs,multiplyUnivariate(positivePolynomials[t],powers[4-t]),12*t);
}
addShifted(rhs,Array(12).fill(72n),48);
const kstar = Array(21).fill(0n);
for (const [degree,coefficient] of [[0,2],[3,-2],[4,-2],[8,2],[20,1]]) kstar[degree] = BigInt(coefficient);
const lhs = multiplyUnivariate(kstar,cyclotomicNumerator);
for (let i = 0; i < Math.max(lhs.length,rhs.length); i++) {
  assert((lhs[i] ?? 0n) === (rhs[i] ?? 0n), `Kstar identity fails at degree ${i}`);
}

console.log("Independent rational-numerator / direct-cubic BigInt verifier");
console.log("Regions:", JSON.stringify(counts));
console.log("Cones:", cones.length, "nonzero monomial coefficients:", monomialCount,
  "minimum:", minimum.toString());
console.log("All symbolic coefficients are nonnegative; no support boundary is crossed.");
console.log("Kstar positive decomposition: exact polynomial identity verified.");
console.log("PASS (ordinary exact computation, not proof-assistant formalization).");
