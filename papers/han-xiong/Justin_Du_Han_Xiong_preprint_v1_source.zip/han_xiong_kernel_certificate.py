"""Internal exact-integer certificate for K_j(q)/(q;q)_4 >= 0, j >= 2.

This is not a scan over j or n.  Every case below leaves its one or two
unbounded parameters symbolic.  The finite cases are residue classes and
an exhaustive decomposition of rational cones.

K_j = (1-q^(4j-1))(1-q^(4j)) - 2q^(7j) + 2q^(8j) + q^(16j+4).

For n < 7j, positivity follows directly from
  (1-q^(4j-1))(1-q^(4j))/(q;q)_4
    = [4j-1]_q [j]_(q^4) / ((1-q^2)(1-q^3)).

For n >= 7j, six times the coefficient is a polynomial with integer
coefficients on each case.  This program verifies that every monomial
coefficient is nonnegative.  No floating-point arithmetic is used.

Why the p_4 quasi-polynomial is exact: (q;q)_4 divides (1-q^12)^4,
and the quotient has degree 38.  After splitting by residue mod 12, each
numerator has degree at most 3 in q^12.  Thus p_4(12m+r) is an exact cubic
polynomial for all integers m >= 0 and is determined by its first four
values (not merely an interpolation conjecture).
"""

from collections import Counter
from itertools import product


def clean(p):
    return {k: v for k, v in p.items() if v}


def const(c):
    return {(0, 0): c} if c else {}


def add(*polys):
    out = {}
    for p in polys:
        for mon, value in p.items():
            out[mon] = out.get(mon, 0) + value
    return clean(out)


def scale(p, c):
    return clean({mon: value * c for mon, value in p.items()})


def multiply(a, b):
    out = {}
    for (a0, a1), av in a.items():
        for (b0, b1), bv in b.items():
            mon = (a0 + b0, a1 + b1)
            out[mon] = out.get(mon, 0) + av * bv
    return clean(out)


# Exact p_4 values, only used to derive the 12 cubic formulas.
partitions = [0] * 48
partitions[0] = 1
for part in range(1, 5):
    for n in range(part, len(partitions)):
        partitions[n] += partitions[n - part]

# Row r gives the coefficients of 1,m,m^2,m^3 in 6*p_4(12m+r).
P4_SIX = []
for r in range(12):
    y0, y1, y2, y3 = [partitions[12 * m + r] for m in range(4)]
    d0 = y0
    d1 = y1 - y0
    d2 = y2 - 2 * y1 + y0
    d3 = y3 - 3 * y2 + 3 * y1 - y0
    P4_SIX.append((6*d0, 6*d1 - 3*d2 + 2*d3, 3*d2 - 3*d3, d3))


def p4_six_of_linear(a, b, c):
    """6*p_4(a*x+b*y+c), with x,y >= 0 and fixed residue mod 12."""
    assert min(a, b, c) >= 0
    assert a % 12 == b % 12 == 0
    r = c % 12
    m = clean({(1, 0): a // 12, (0, 1): b // 12, (0, 0): c // 12})
    m2 = multiply(m, m)
    m3 = multiply(m2, m)
    c0, c1, c2, c3 = P4_SIX[r]
    return add(const(c0), scale(m, c1), scale(m2, c2), scale(m3, c3))


# A tuple (a,b,w) contributes w*p_4(n-a*j-b), with p_4(t)=0 for t<0.
KERNEL_TERMS = (
    (0, 0, 1), (4, -1, -1), (4, 0, -1), (8, -1, 1),
    (7, 0, -2), (8, 0, 2), (16, 4, 1),
)


def kernel_polynomial(j, n):
    """j,n are linear triples (x coefficient,y coefficient,constant)."""
    out = {}
    for a, b, weight in KERNEL_TERMS:
        argument = tuple(n[i] - a*j[i] - (b if i == 2 else 0) for i in range(3))
        if argument[2] < 0 and max(argument[:2]) <= 0:
            # This argument is negative for every x,y >= 0, so it is zero.
            continue
        assert min(argument) >= 0, ("case crosses a support boundary", j, n, argument)
        out = add(out, scale(p4_six_of_linear(*argument), weight))
    return out


def cases():
    """Yield (region name,j(x,y),n(x,y)) for the exhaustive certificate."""

    # I1: 7j <= n <= 8j-2.  Put r=n-7j, t=j-r-2, both >=0.
    # Then r=12x+r0, t=12y+t0.
    for r, t in product(range(12), repeat=2):
        yield "I1", (12, 12, r+t+2), (96, 84, 8*r+7*t+14)

    # I2: n=8j-1, j=12x+r+2.
    for r in range(12):
        yield "I2", (12, 0, r+2), (96, 0, 8*r+15)

    # I3: 8j <= n <= 16j-1.  Write n-8j=8a+b, 0<=b<=7,
    # and j=a+t+1.  Thus a,t>=0 and a+t>=1.
    # Split a>=1 (a=1+12x+r,t=12y+t0) and a=0 (t>=1).
    for b, r, t in product(range(8), range(12), range(12)):
        yield "I3a", (12, 12, r+t+2), (192, 96, 16*r+8*t+24+b)
    for b, t in product(range(8), range(12)):
        yield "I3b", (12, 0, t+2), (96, 0, 8*t+16+b)

    # I4: n=16j+u, u=0,1,2,3; j=12x+r+2.
    for u, r in product(range(4), range(12)):
        yield "I4", (12, 0, r+2), (192, 0, 16*r+32+u)

    # I5: n=16j+4+t.  Write j=12J+r+2, t=12T+v,
    # 0<=r,v<=11 and J,T>=0.  Split the cones T<=8J and T>=8J.
    for r, v in product(range(12), repeat=2):
        # Lower cone: T=8x+b; J=x+y+d, where d=0 for b=0,
        # d=1 otherwise.  This is exactly J>=ceil(T/8).
        for b in range(8):
            d = int(b != 0)
            yield "I5lower", (12, 12, r+2+12*d), (288, 192, 16*r+36+192*d+12*b+v)

        # Upper cone: T=8J+V.  V=0,...,4 are separate faces;
        # V>=5 is written V=5+y.  J=x in all these cases.
        for V in range(5):
            yield "I5face", (12, 0, r+2), (288, 0, 16*r+36+12*V+v)
        yield "I5upper", (12, 0, r+2), (288, 12, 16*r+96+v)


def main():
    counts = Counter()
    checked_monomials = 0
    minimum = None
    for region, j, n in cases():
        polynomial = kernel_polynomial(j, n)
        negative = {mon: value for mon, value in polynomial.items() if value < 0}
        assert not negative, (region, j, n, negative)
        counts[region] += 1
        checked_monomials += len(polynomial)
        if polynomial:
            lo = min(polynomial.values())
            minimum = lo if minimum is None else min(minimum, lo)
    assert sum(counts.values()) == 3468
    print("Exact quasi-polynomial rows for 6*p4(12m+r):", P4_SIX)
    print("Case counts:", dict(counts))
    print("All symbolic monomial coefficients nonnegative.")
    print("Cases:", sum(counts.values()), "monomials:", checked_monomials, "minimum nonzero coefficient:", minimum)


if __name__ == "__main__":
    main()
