"""Exact symbolic certificate for Q_a(q)/(q;q)_4 >= 0, all integers a>=3.

Q_a=(1-q^(2a-1))(1-q^(2a))-q^(3a+1)+q^(4a)+q^(8a+4).

This is NOT a finite scan over a or the coefficient index n. Every case
below leaves one or two nonnegative integer parameters x,y unbounded.
On each case, six times the coefficient is an exact integer polynomial
in x,y. All monomial coefficients of those polynomials are checked.

For n<3a+1, positivity follows without this certificate from
  (1-q^(2a-1))(1-q^(2a))/(q;q)_4
    = [2a-1]_q [a]_(q^2) / ((1-q^3)(1-q^4)).

The remaining range is decomposed exhaustively as follows:
  I1: 3a+1 <= n <= 4a-2;
  I2: n=4a-1;
  I3: 4a <= n <= 8a+3;
  I4: n >= 8a+4.
See cases() for the exact parametrizations and their inverses.

The cubic formulas for p4(n)=[q^n]1/(q;q)_4 are derived from the exact
polynomial identity R(q)=(1-q^12)^4/(q;q)_4, not from extrapolating data.
All calculations use Python integers only. There are no floating-point
calculations, external dependencies, bounded-parameter assumptions,
sampling assumptions, or empirical positivity thresholds.
"""

from collections import Counter
from itertools import product
import argparse
import json


def clean(p):
    return {mon: value for mon, value in p.items() if value}


def const(c):
    return {(0, 0): c} if c else {}


def add(*polys):
    out = {}
    for p in polys:
        for mon, value in p.items():
            out[mon] = out.get(mon, 0) + value
    return clean(out)


def scale(p, c):
    return clean({mon: value * c for mon, value in p.items()})


def multiply(p, q):
    out = {}
    for (pi, pj), pv in p.items():
        for (qi, qj), qv in q.items():
            mon = (pi + qi, pj + qj)
            out[mon] = out.get(mon, 0) + pv * qv
    return clean(out)


def derive_p4_rows():
    """Return R(q) and exact cubic rows for 6*p4(12m+r), m>=0.

    R(q) = product_{d=1}^4 sum_{i=0}^{12/d-1} q^(di), degree 38.
    For a fixed residue r, the contribution of R[12j+r] is
    6*binomial(m-j+3,3) = (m-j+1)(m-j+2)(m-j+3).
    Since 0<=j<=3, this polynomial is zero when 0<=m<j, exactly
    matching the absence of a negative coefficient index.
    """
    R = [1]
    for d in range(1, 5):
        out = [0] * (len(R) + 12 - d)
        for exponent, coefficient in enumerate(R):
            for i in range(12 // d):
                out[exponent + d * i] += coefficient
        R = out
    assert len(R) == 39
    rows = []
    for r in range(12):
        row = [0, 0, 0, 0]
        for j in range(4):
            exponent = 12 * j + r
            if exponent >= len(R):
                continue
            u, v, w = 1-j, 2-j, 3-j
            cubic = (u*v*w, u*v+u*w+v*w, u+v+w, 1)
            for degree, value in enumerate(cubic):
                row[degree] += R[exponent] * value
        rows.append(tuple(row))
    return R, rows


R_COEFFICIENTS, P4_SIX = derive_p4_rows()


def p4_six_of_linear(alpha, beta, gamma):
    """Polynomial 6*p4(alpha*x+beta*y+gamma), for x,y>=0."""
    assert min(alpha, beta, gamma) >= 0
    assert alpha % 12 == beta % 12 == 0
    residue = gamma % 12
    m = clean({(1, 0): alpha // 12, (0, 1): beta // 12,
               (0, 0): gamma // 12})
    m2 = multiply(m, m)
    m3 = multiply(m2, m)
    c0, c1, c2, c3 = P4_SIX[residue]
    return add(const(c0), scale(m, c1), scale(m2, c2), scale(m3, c3))


# (s,t,w) contributes w*p4(n-s*a-t), with p4(negative)=0.
KERNEL_TERMS = (
    (0, 0, 1), (2, -1, -1), (2, 0, -1), (4, -1, 1),
    (3, 1, -1), (4, 0, 1), (8, 4, 1),
)


def kernel_polynomial(a, n):
    """a,n are triples (x coefficient,y coefficient,constant)."""
    out = {}
    for s, t, weight in KERNEL_TERMS:
        argument = tuple(n[i] - s*a[i] - (t if i == 2 else 0)
                         for i in range(3))
        if argument[2] < 0 and max(argument[:2]) <= 0:
            # Strictly negative throughout this entire unbounded case.
            continue
        assert min(argument) >= 0, (
            "case crosses a support boundary", a, n, argument)
        out = add(out, scale(p4_six_of_linear(*argument), weight))
    return out


def cases():
    """Yield (region,a(x,y),n(x,y)); every x,y is an arbitrary integer >=0."""

    # I1: put u=n-3a-1, t=4a-2-n. Then u,t>=0, a=u+t+3,
    # n=4u+3t+10. Split u=12x+r and t=12y+v.
    for r, v in product(range(12), repeat=2):
        yield "I1", (12, 12, r+v+3), (48, 36, 4*r+3*v+10)

    # I2: n=4a-1 and a=12x+r+3.
    for r in range(12):
        yield "I2", (12, 0, r+3), (48, 0, 4*r+11)

    # I3: write n-4a=4b+u, 0<=u<=3. The upper bound gives
    # 0<=b<=a. Put t=a-b, so b,t>=0 and b+t>=3.
    # Split b>=3 from b=0,1,2; these alternatives are exhaustive.
    # For b>=3: b=3+12x+r, t=12y+v.
    for u, r, v in product(range(4), range(12), range(12)):
        yield "I3a", (12, 12, r+v+3), (96, 48, 8*r+4*v+24+u)
    # For b=0,1,2: t=3-b+12x+r, hence a=3+12x+r.
    for u, b, r in product(range(4), range(3), range(12)):
        yield "I3b", (12, 0, r+3), (48, 0, 4*r+12+4*b+u)

    # I4: uniquely write a=12A+r+3 and n=8a+4+12T+v,
    # with A,T>=0 and 0<=r,v<=11. Split T<=3A and T>=3A.
    # The common boundary T=3A is deliberately covered twice.
    for r, v in product(range(12), repeat=2):
        # Lower cone: T=3x+b, 0<=b<=2. A=x+y+d, where
        # d=0 if b=0, and d=1 otherwise; equivalently A>=ceil(T/3).
        for b in range(3):
            d = int(b != 0)
            yield "I4lower", (12, 12, r+3+12*d), (
                132, 96, 8*r+28+96*d+12*b+v)

        # Upper cone: T=3A+V. Separate V=0,1,2 from V>=3.
        # In the first case A=x; in the last, A=x and V=3+y.
        for V in range(3):
            yield "I4face", (12, 0, r+3), (
                132, 0, 8*r+28+12*V+v)
        yield "I4upper", (12, 0, r+3), (132, 12, 8*r+64+v)


def verify():
    counts = Counter()
    checked_monomials = 0
    minimum = None
    records = []
    for region, a, n in cases():
        polynomial = kernel_polynomial(a, n)
        negative = {mon: value for mon, value in polynomial.items() if value < 0}
        assert not negative, (region, a, n, negative)
        counts[region] += 1
        checked_monomials += len(polynomial)
        if polynomial:
            lo = min(polynomial.values())
            minimum = lo if minimum is None else min(minimum, lo)
        records.append({
            "region": region, "a": a, "n": n,
            "six_times_coefficient": [
                [i, j, coefficient]
                for (i, j), coefficient in sorted(polynomial.items())],
        })
    assert dict(counts) == {
        "I1": 144, "I2": 12, "I3a": 576, "I3b": 144,
        "I4lower": 432, "I4face": 432, "I4upper": 144,
    }
    assert len(records) == 1884
    return {
        "statement": "Q_a/(q;q)_4 has nonnegative coefficients for all integers a>=3",
        "parameter_domain": "Every displayed x,y is an unbounded nonnegative integer",
        "R_coefficients": R_COEFFICIENTS,
        "P4_SIX": P4_SIX,
        "region_counts": dict(counts),
        "cases": len(records),
        "nonzero_monomial_coefficients": checked_monomials,
        "minimum_nonzero_coefficient": minimum,
        "records": records,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", help="Optionally write the full exact certificate here")
    args = parser.parse_args()
    certificate = verify()
    print("Exact cubic rows for 6*p4(12m+r):", P4_SIX)
    print("Region counts:", certificate["region_counts"])
    print("All symbolic monomial coefficients are nonnegative.")
    print("Cases:", certificate["cases"],
          "nonzero monomial coefficients:", certificate["nonzero_monomial_coefficients"],
          "minimum nonzero coefficient:", certificate["minimum_nonzero_coefficient"])
    print("Together with elementary positivity for n<3a+1, this covers every a>=3,n>=0.")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as output:
            json.dump(certificate, output, ensure_ascii=False, separators=(",", ":"))
            output.write("\n")
        print("Full certificate written to", args.json)


if __name__ == "__main__":
    main()
